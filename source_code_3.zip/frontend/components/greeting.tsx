"use client";
import { useUser } from '@/providers/AppProvider';
import { motion } from 'framer-motion';
import { GradientText } from './ui/gradient-text';
import { TextShimmer } from './ui/text-shimmer';

export const Greeting = () => {

  const { user } = useUser();


  return (
    <div
      key="overview"
      className="max-w-3xl mx-auto md:mt-20 px-8 size-full flex flex-col justify-center"
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 10 }}
        transition={{ delay: 0.5 }}
        className=""
      >
        <TextShimmer
          duration={10}
          className='text-4xl font-semibold [--base-color:theme(colors.gray.900)] [--base-gradient-color:theme(colors.gray.500)] dark:[--base-color:theme(colors.gray.700)] dark:[--base-gradient-color:theme(colors.gray.400)]'
        >
          Hello {user?.username ? user.username.charAt(0).toUpperCase() + user.username.slice(1) : 'Guest'}!
        </TextShimmer>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 10 }}
        transition={{ delay: 0.6 }}
        className="text-4xl font-bold tracking-tighter md:text-5xl pb-12 lg:text-4xl"
      >
        How can I <GradientText>help you</GradientText> today?
      </motion.div>
    </div>
  );
};
