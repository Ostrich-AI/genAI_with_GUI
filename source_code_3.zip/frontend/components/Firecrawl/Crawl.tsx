
import FirecrawlApp from '@mendable/firecrawl-js';

const app = new FirecrawlApp({ apiKey: "fc-cd1df9f9e59c4297a70b3d4065206cba" });

// Crawl a website:
await app.crawlUrl(
 "docs.firecrawl.dev", { 
 excludePaths: ["blog/.+"],
 limit: 5
 }
);