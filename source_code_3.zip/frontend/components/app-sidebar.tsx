"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { NavUser } from "@/components/nav-user";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar";
import {
  RiSlowDownLine,
  RiLinksLine,
  RiHome2Line,
  RiUserLine,
  RiDatabase2Line,
  RiSettings3Line,
  RiFlashlightLine,
  RiChatAiFill,
  RiFlashlightFill,
  RiSettings3Fill,
  RiDatabase2Fill,
  RiUserFill,
  RiHome2Fill,
  RiLinksFill,
} from "@remixicon/react";

// Move data outside component to avoid recreating on each render
const data = {
  user: {
    name: "Mark Bannert",
    email: "mark@bannert.com",
    avatar: "\public\image.png",
  },
  navMain: [
    {
      title: "General",
      items: [
        {
          title: "Dashboard",
          url: "/home",
          icon: RiHome2Fill,
        },
        {
          title: "Users",
          url: "/home/users",
          icon: RiUserFill,
        },
        {
          title: "Knowledge Base",
          url: "/home/ingest",
          icon: RiDatabase2Fill,
        },
        {
          title: "Pro Mode",
          url: "/home/pro-mode",
          icon: RiFlashlightFill,
        },
        {
          title: "Chat",
          url: "/",
          icon: RiChatAiFill,
        },
        {
          title: "Feedback",
          url: "./feedback",
          icon: RiLinksFill,
        },
      ],
    },
  ],
};

function SidebarLogo() {
  const id = React.useId();
  return (
    <div className="flex gap-2 px-2 group-data-[collapsible=icon]:px-0 transition-[padding] duration-200 ease-in-out">
      <Link className="group/logo inline-flex" href="/">
        <span className="sr-only">Kiwi AI</span>
        <img
          src="/kiwi.png"
          alt="Kiwi AI Logo"
          className="w-[96px] h-[48px] group-data-[collapsible=icon]:w-[80px] group-data-[collapsible=icon]:h-[40px] transition-[width,height] duration-200 ease-in-out"
        />
      </Link>
    </div>
  );
}

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();

  return (
    <Sidebar collapsible="icon" variant="inset" {...props}>
      <SidebarHeader className="h-16 max-md:mt-2 mb-2 justify-center">
        <SidebarLogo />
      </SidebarHeader>
      <SidebarContent className="-mt-2">
        {data.navMain.map((item) => (
          <SidebarGroup key={item.title}>
            <SidebarGroupLabel className="uppercase text-muted-foreground/65">
              {item.title}
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {item.items.map((item) => {
                  const isActive = 
                    pathname === item.url ||
                    (pathname.startsWith(item.url) && item.url !== '/');

                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        className="group/menu-button group-data-[collapsible=icon]:px-[5px]! font-medium gap-3 h-9 [&>svg]:size-auto"
                        tooltip={item.title}
                        isActive={isActive}
                      >
                        <Link href={item.url}>
                          {item.icon && (
                            <item.icon
                              className={`text-muted-foreground/65 ${
                                isActive ? 'text-primary' : ''
                              } group-data-[active=true]/menu-button:text-primary`}
                              size={22}
                              aria-hidden="true"
                            />
                          )}
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
    </Sidebar>
  );
}