// components/RequireAuth.tsx
import { useRouter } from "next/navigation";

interface RequireAuthProps {
  message?: string;
}

function RequireAuth({ message = "Please log in." }: RequireAuthProps) {
  const router = useRouter();

  return (
    <div>
      <p>{message}</p>
      <button onClick={() => router.push("/login")}>Login</button>
    </div>
  );
}

export default RequireAuth;
