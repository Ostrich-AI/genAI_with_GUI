'use client';

import { Button } from "./ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "./ui/card";
import { API_URL } from "@/lib/constants";

interface EmailData {
  to: string;
  subject: string;
  body: string;
  from?: string;
  timestamp: string;
}

const SAMPLE_EMAIL: EmailData = {
  to: "example@domain.com",
  subject: "Sample Subject",
  body: "Loading email content...",
  timestamp: new Date().toISOString()
};

export function Email({
  emailData = SAMPLE_EMAIL
}: {
  emailData?: EmailData;
}) {
  const handleSendEmail = async () => {
    try {
      const response = await fetch(`${API_URL}/mail/send-mail`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'accept': 'application/json',
        },
        body: JSON.stringify({
          to: emailData.to,
          subject: emailData.subject,
          body_text: emailData.body,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to send email: ${response.statusText}`);
      }

      const result = await response.json();
      console.log('Email sent successfully:', result);
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  return (
    <Card className="w-full max-w-[600px]">
      <CardHeader>
        <CardTitle>Draft Email</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground">To:</div>
          <div className="font-medium">{emailData.to}</div>
        </div>
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground">Subject:</div>
          <div className="font-medium">{emailData.subject}</div>
        </div>
        <div className="space-y-2">
          <div className="text-sm text-muted-foreground">Body:</div>
          <div className="whitespace-pre-wrap rounded-md bg-muted p-4">
            {emailData.body}
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSendEmail} className="w-full">
          Send Email
        </Button>
      </CardFooter>
    </Card>
  );
}