import React, { useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileUp, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

interface FileUploadProps {
  selectedFiles: File[];
  uploadedUrls: string[];
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onUpload: () => void;
}

const FileUpload: React.FC<FileUploadProps> = ({
  selectedFiles,
  uploadedUrls,
  onFileSelect,
  onUpload,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const files = Array.from(e.dataTransfer.files);
    if (fileInputRef.current) {
      const dataTransfer = new DataTransfer();
      files.forEach(file => dataTransfer.items.add(file));
      fileInputRef.current.files = dataTransfer.files;
      const event = { target: { files: dataTransfer.files } } as React.ChangeEvent<HTMLInputElement>;
      onFileSelect(event);
    }
  };

  return (
    <Card className="shadow-lg border-2 border-primary/10">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl">Upload Your Files</CardTitle>
        <p className="text-sm text-muted-foreground">
          Drag and drop your files or click to browse
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className={cn(
            "border-2 border-dashed border-muted-foreground/25",
            "rounded-lg p-8 text-center transition-colors duration-200",
            "hover:bg-muted/50 cursor-pointer relative min-h-[200px]",
            "flex flex-col items-center justify-center gap-4"
          )}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className="h-12 w-12 text-muted-foreground/50" />
          <div className="space-y-2">
            <p className="text-xl font-medium">Drop your files here</p>
            <p className="text-sm text-muted-foreground">
              or click to browse from your computer
            </p>
          </div>
          <input
            type="file"
            multiple
            onChange={onFileSelect}
            ref={fileInputRef}
            className="hidden"
          />
        </div>

        {selectedFiles.length > 0 && (
          <div className="space-y-2">
            <p className="text-lg font-medium flex items-center gap-2">
              <FileUp className="h-5 w-5" />
              {selectedFiles.length} file(s) selected
            </p>
            <ul className="text-sm text-muted-foreground space-y-1">
              {Array.from(selectedFiles).map((file, index) => (
                <li key={index} className="truncate">{file.name}</li>
              ))}
            </ul>
          </div>
        )}

        {uploadedUrls.length > 0 && (
          <div className="rounded-lg bg-muted/50 p-4 space-y-2">
            <p className="font-medium">Uploaded Files:</p>
            <ul className="text-sm text-muted-foreground space-y-1">
              {uploadedUrls.map((url, index) => (
                <li key={index} className="truncate">
                  {decodeURIComponent(url.split('/').pop() || '')}
                </li>
              ))}
            </ul>
          </div>
        )}

        <Button 
          type="button"
          onClick={onUpload}
          disabled={selectedFiles.length === 0}
          className="w-full h-12 text-lg"
        >
          <FileUp className="h-5 w-5 mr-2" />
          Upload Files
        </Button>
      </CardContent>
    </Card>
  );
};

export default FileUpload; 