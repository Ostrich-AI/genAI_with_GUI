import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, Edit } from "lucide-react";
import api from "@/utils/api";
import Loading from "@/components/Loading";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useRouter } from "next/navigation";
import { API_URL } from "@/lib/constants";

interface Agent {
  id: number;
  bot_id: string;
  name: string;
  nodes: any[];
  edges: any[];
  notion_url: string | null;
  gdrive_url: string | null;
  additional_details: string | null;
  created_at: string;
  updated_at: string;
}

const ProModeContent: React.FC = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleCreateNew = async () => {
    try {
      // Create a temporary agent first
      const response = await api(`${API_URL}/agent/create`, {
        method: "POST",
        body: JSON.stringify({
          name: "New Agent",
          description: "",
          nodes: [],
          edges: [],
        }),
      });
      
      // Redirect to the maker page with the new bot_id
      router.push(`/maker/${response.data.bot_id}`);
    } catch (error) {
      console.error("Failed to create agent:", error);
      setError("Failed to create agent");
    }
  };

  const fetchAgents = async () => {
    try {
      const response = await api(`${API_URL}/agent/list`);
      setAgents(response.data);
      setError(null);
    } catch (error) {
      console.error("Failed to fetch agents:", error);
      setError("Failed to load agents");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAgents();
  }, []);

  const handleDelete = async (botId: string) => {
    try {
      await api(`${API_URL}/agent/${botId}`, {
        method: "DELETE",
      });
      await fetchAgents(); // Refresh the list
      setError(null);
    } catch (error) {
      console.error("Failed to delete agent:", error);
      setError("Failed to delete agent");
    }
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Pro Mode Agents</h1>
        <Button onClick={handleCreateNew}>
          <Plus className="mr-2 h-4 w-4" />
          Create New Agent
        </Button>
      </div>
      
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {agents.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center">
              <p className="text-muted-foreground">No pro mode agents created yet.</p>
            </CardContent>
          </Card>
        ) : (
          agents.map((agent) => (
            <Card key={agent.bot_id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{agent.name}</span>
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => router.push(`/maker/${agent.bot_id}`)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(agent.bot_id)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Nodes: {agent.nodes.length}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Edges: {agent.edges.length}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Last updated: {new Date(agent.updated_at).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default ProModeContent; 