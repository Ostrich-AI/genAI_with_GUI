// components/dashboard/DashboardContent.tsx
import React, { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, UserCheck, ShieldCheck, Info } from "lucide-react";
import api from "@/utils/api";
import Loading from "@/components/Loading";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { User } from "@/types/user";
import ActiveUsers from "./ActiveUsers";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { API_URL } from "@/lib/constants";

interface UserStats {
  totalUsers: number;
  activeUsers: number;
  adminUsers: number;
}

const DashboardContent: React.FC = () => {
  const [stats, setStats] = useState<UserStats>({
    totalUsers: 0,
    activeUsers: 0,
    adminUsers: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showHelp, setShowHelp] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await api(`${API_URL}/users/`);
        console.log("Stats response:", response); // For debugging
        
        const users = Array.isArray(response) ? response : response?.users || [];
        const adminUsers = users.filter((user: User) => user.is_admin).length;
        
        setStats({
          totalUsers: users.length,
          activeUsers: users.length, // Since we don't track active status, using total for now
          adminUsers: adminUsers
        });
        setError(null);
      } catch (error) {
        console.error("Failed to fetch stats:", error);
        setError("Failed to load dashboard statistics");
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) return <Loading />;

  return (
    <TooltipProvider>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold">Dashboard Overview</h1>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <Info className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent className="max-w-sm">
              <p>This dashboard shows information about users in the system. Click on cards to see more details.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        
        {showHelp && (
          <Alert className="bg-blue-500/10 border-blue-500 text-blue-500">
            <div className="flex justify-between items-center">
              <AlertDescription>
                Welcome to your dashboard! Here you can see information about users and who's currently online.
                Hover over items with your mouse to learn more about them.
              </AlertDescription>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setShowHelp(false)}
                className="ml-2 h-8"
              >
                Got it
              </Button>
            </div>
          </Alert>
        )}
        
        {error && (
          <Alert variant="destructive">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="cursor-help">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    Total registered users
                  </p>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p>This shows how many people have accounts in the system.</p>
            </TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="cursor-help">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                  <UserCheck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.activeUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    Currently registered users
                  </p>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p>These are users who have active accounts and can use the system.</p>
            </TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="cursor-help">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Admins</CardTitle>
                  <ShieldCheck className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.adminUsers}</div>
                  <p className="text-xs text-muted-foreground">
                    Users with admin privileges
                  </p>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent>
              <p>Admins are special users who can change settings and manage other users.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <ActiveUsers />
      </div>
    </TooltipProvider>
  );
};

export default DashboardContent;
