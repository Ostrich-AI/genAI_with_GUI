import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Link2 } from 'lucide-react';
import { API_URL } from '@/lib/constants';

interface OtherSourcesProps {
  notionUrl: string;
  gdriveUrl: string;
  dropboxUrl: string;
  onNotionUrlChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onGdriveUrlChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDropboxUrlChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const OtherSources: React.FC<OtherSourcesProps> = ({
  notionUrl,
  gdriveUrl,
  dropboxUrl,
  onNotionUrlChange,
  onGdriveUrlChange,
  onDropboxUrlChange,
}) => {
  const [siteScraperUrl, setSiteScraperUrl] = useState('');

  const handleSubmit = async () => {
    if (!siteScraperUrl) {
      console.error('Site Scraper URL is empty');
      return;
    }

    try {
      const response = await fetch(`${API_URL}/crawl`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          accept: 'application/json',
        },
        body: JSON.stringify({ url: siteScraperUrl }),
      });

      if (!response.ok) {
        throw new Error(`Network response was not ok: ${response.status}`);
      }

      console.log('Scrape submitted successfully');
    } catch (error) {
      console.error('Error submitting scrape:', error);
    }
  };

  const handleSiteScraperUrlChange = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    setSiteScraperUrl(e.target.value);
  };

  return (
    <Card className="shadow-sm border border-primary/10">
      <CardContent className="pt-6">
        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="other-sources" className="border-none">
            <AccordionTrigger className="text-xl py-2 flex items-center gap-2 [&[data-state=open]>svg]:rotate-180">
              <Link2 className="h-5 w-5" />
              Other Knowledge Sources
            </AccordionTrigger>
            <AccordionContent className="space-y-6 pt-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-lg font-medium block">
                    Notion Workspace or Page
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add your Notion workspace or specific page URL to import
                    content
                  </p>
                  <Input
                    value={notionUrl}
                    onChange={onNotionUrlChange}
                    placeholder="https://www.notion.so/your-workspace"
                    type="url"
                    className="h-12 text-lg"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-lg font-medium block">
                    Google Drive Folder
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add a Google Drive folder URL to import documents
                  </p>
                  <Input
                    value={gdriveUrl}
                    onChange={onGdriveUrlChange}
                    placeholder="https://drive.google.com/drive/folders/..."
                    type="url"
                    className="h-12 text-lg"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-lg font-medium block">
                    Dropbox Folder
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Add a Dropbox folder or file URL to import content
                  </p>
                  <Input
                    value={dropboxUrl}
                    onChange={onDropboxUrlChange}
                    placeholder="https://www.dropbox.com/sh/..."
                    type="url"
                    className="h-12 text-lg"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-lg font-medium block">
                    Site Scraper
                  </label>
                  <p className="text-sm text-muted-foreground">
                    Paste a site to scrape the data from
                  </p>
                  <Input
                    placeholder={`${API_URL}/crawl`}
                    type="url"
                    className="h-12 text-lg"
                    value={siteScraperUrl}
                    onChange={handleSiteScraperUrlChange}
                  />
                  <div className="flex justify-start">
                    <button
                      className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
                      onClick={handleSubmit}
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
};

export default OtherSources;
