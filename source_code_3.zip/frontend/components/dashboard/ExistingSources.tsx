import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, FileText, Link2, Database, Building2, Shield } from "lucide-react";
import { cn } from "@/lib/utils";
import { KnowledgeSource } from "@/types/knowledge";
import { Badge } from "@/components/ui/badge";

interface ExistingSourcesProps {
  sources: KnowledgeSource[];
  onDelete: (id: number) => void;
}

const getSensitivityColor = (sensitivity: string) => {
  switch (sensitivity) {
    case 'restricted':
      return 'bg-red-500/10 text-red-500 hover:bg-red-500/20';
    case 'confidential':
      return 'bg-orange-500/10 text-orange-500 hover:bg-orange-500/20';
    default:
      return 'bg-green-500/10 text-green-500 hover:bg-green-500/20';
  }
};

const ExistingSources: React.FC<ExistingSourcesProps> = ({
  sources,
  onDelete,
}) => {
  if (sources.length === 0) {
    return (
      <Card className="shadow-sm border border-primary/10">
        <CardContent className="p-6">
          <div className="text-center space-y-2">
            <Database className="h-12 w-12 mx-auto text-muted-foreground/50" />
            <h3 className="text-lg font-medium">No Sources Yet</h3>
            <p className="text-sm text-muted-foreground">
              Upload files or add external sources to get started
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold">Your Knowledge Sources</h2>
        <p className="text-sm text-muted-foreground">
          {sources.length} source{sources.length !== 1 ? 's' : ''}
        </p>
      </div>

      <div className="grid gap-4">
        {sources.map((source) => (
          <Card 
            key={source.id} 
            className={cn(
              "shadow-sm hover:shadow-md transition-shadow duration-200",
              "border border-primary/10"
            )}
          >
            <CardContent className="p-6">
              <div className="flex flex-col gap-4">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <Badge variant="secondary" className="flex items-center gap-1">
                      <Building2 className="h-3 w-3" />
                      {source.department}
                    </Badge>
                    <Badge 
                      variant="secondary" 
                      className={cn("flex items-center gap-1", 
                        getSensitivityColor(source.sensitivity)
                      )}
                    >
                      <Shield className="h-3 w-3" />
                      {source.sensitivity.charAt(0).toUpperCase() + source.sensitivity.slice(1)}
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onDelete(source.id)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </div>

                <div className="space-y-4">
                  {source.notion_urls.length > 0 && (
                    <div className="flex items-start gap-3">
                      <Link2 className="h-5 w-5 text-blue-500 mt-1 flex-shrink-0" />
                      <div className="space-y-1 min-w-0">
                        <p className="font-medium">Notion</p>
                        <ul className="space-y-1">
                          {source.notion_urls.map((url, idx) => (
                            <li key={idx} className="text-sm text-muted-foreground truncate">
                              {url}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}

                  {source.gdrive_urls.length > 0 && (
                    <div className="flex items-start gap-3">
                      <Link2 className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                      <div className="space-y-1 min-w-0">
                        <p className="font-medium">Google Drive</p>
                        <ul className="space-y-1">
                          {source.gdrive_urls.map((url, idx) => (
                            <li key={idx} className="text-sm text-muted-foreground truncate">
                              {url}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}

                  {source.file_urls.length > 0 && (
                    <div className="flex items-start gap-3">
                      <FileText className="h-5 w-5 text-orange-500 mt-1 flex-shrink-0" />
                      <div className="space-y-1 min-w-0">
                        <p className="font-medium">Files</p>
                        <ul className="space-y-1">
                          {source.file_urls.map((url, idx) => (
                            <li key={idx} className="text-sm text-muted-foreground truncate">
                              {decodeURIComponent(url.split('/').pop() || '')}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ExistingSources; 