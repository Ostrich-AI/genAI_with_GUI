// components/dashboard/UsersContent.tsx
import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Edit, Save, X, Trash2, Plus } from "lucide-react";
import api from "@/utils/api";
import { User } from "@/types/user";
import Loading from "@/components/Loading";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { API_URL } from "@/lib/constants";

interface UserFormData {
  username: string;
  password: string;
  role: string;
  is_admin: boolean;
  employee_status: string;
}

const UsersContent: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [newUser, setNewUser] = useState<UserFormData>({
    username: "",
    password: "",
    role: "intern",
    is_admin: false,
    employee_status: "full-time"
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const fetchUsers = async () => {
    try {
      const response = await api(`${API_URL}/users/`);
      console.log("Raw API response:", response);
      console.log("Users array:", response.users);
      
      if (!response.users || !Array.isArray(response.users)) {
        console.error("Invalid response format:", response);
        setError("Invalid response format from server");
        setUsers([]);
        return;
      }

      // Log each user's data
      response.users.forEach((user: User, index: number) => {
        console.log(`User ${index}:`, {
          username: user.username,
          role: user.role,
          employee_status: user.employee_status,
          is_admin: user.is_admin
        });
      });

      setUsers(response.users);
      setError(null);
    } catch (error) {
      console.error("Failed to fetch users:", error);
      setError("Failed to load users");
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleEditClick = (username: string) => {
    setEditingUserId(username);
  };

  const handleRoleChange = async (username: string, newRole: string) => {
    try {
      await api(`${API_URL}/users/${username}/role?new_role=${newRole}`, {
        method: "PUT",
      });
      
      await fetchUsers();
      setEditingUserId(null);
      setError(null);
    } catch (error) {
      console.error("Failed to update user role:", error);
      setError("Failed to update user role");
    }
  };

  const handleEmployeeStatusChange = async (username: string, newStatus: string) => {
    try {
      await api(`${API_URL}/users/${username}/employee_status?new_status=${newStatus}`, {
        method: "PUT"
      });
      
      await fetchUsers();
      setEditingUserId(null);
      setError(null);
    } catch (error) {
      console.error("Failed to update employee status:", error);
      setError("Failed to update employee status");
    }
  };

  const handleDeleteUser = async (username: string) => {
    if (!confirm("Are you sure you want to delete this user?")) return;
    
    try {
      await api(`${API_URL}/users/${username}`, {
        method: "DELETE",
      });
      await fetchUsers(); // Refresh the list
      setError(null);
    } catch (error) {
      console.error("Failed to delete user:", error);
      setError("Failed to delete user");
    }
  };

  const handleCreateUser = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    try {
      await api(`${API_URL}/users/`, {
        method: "POST",
        body: JSON.stringify(newUser),
      });
      setIsDialogOpen(false);
      setNewUser({
        username: "",
        password: "",
        role: "intern",
        is_admin: false,
        employee_status: "full-time"
      });
      await fetchUsers();
      setError(null);
    } catch (error) {
      console.error("Failed to create user:", error);
      setError("Failed to create user");
    }
  };

  if (loading) return <Loading />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">User Management</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="rounded-lg transition-all hover:shadow-md">
              <Plus className="h-4 w-4 mr-2" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New User</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreateUser} className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  value={newUser.username}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewUser({ ...newUser, username: e.target.value })
                  }
                  required
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewUser({ ...newUser, password: e.target.value })
                  }
                  required
                />
              </div>
              <div>
                <Label htmlFor="role">Role</Label>
                <Select
                  value={newUser.role}
                  onValueChange={(value) =>
                    setNewUser({ ...newUser, role: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="intern">Intern</SelectItem>
                    <SelectItem value="contractor">Contractor</SelectItem>
                    <SelectItem value="manager">Manager</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="employee_status">Employee Status</Label>
                <Select
                  value={newUser.employee_status}
                  onValueChange={(value) =>
                    setNewUser({ ...newUser, employee_status: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="terminated">Terminated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is_admin"
                  checked={newUser.is_admin}
                  onChange={(e) =>
                    setNewUser({ ...newUser, is_admin: e.target.checked })
                  }
                />
                <Label htmlFor="is_admin">Admin privileges</Label>
              </div>
              <Button type="submit" className="w-full">
                Create User
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}
      
      <div className="rounded-xl border shadow-sm overflow-hidden bg-card">
        <Table>
          <TableHeader className="bg-muted/50 pl-5">
            <TableRow className="hover:bg-muted/30">
              <TableHead className="font-semibold text-sm">ID</TableHead>
              <TableHead className="font-semibold text-sm">Username</TableHead>
              <TableHead className="font-semibold text-sm">Role</TableHead>
              <TableHead className="font-semibold text-sm">Employee Status</TableHead>
              <TableHead className="font-semibold text-sm">Super Admin</TableHead>
              <TableHead className="text-right font-semibold text-sm">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user, index) => (
              <TableRow 
                key={user.username || index} 
                className="hover:bg-muted/30 transition-colors"
              >
                <TableCell className="font-medium text-sm">{index + 1}</TableCell>
                <TableCell className="text-sm">{user.username}</TableCell>
                <TableCell>
                  {editingUserId === user.username ? (
                    <Select
                      defaultValue={user.role}
                      onValueChange={(value) => handleRoleChange(user.username, value)}
                    >
                      <SelectTrigger className="w-32 text-sm h-8">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="intern">Intern</SelectItem>
                        <SelectItem value="contractor">Contractor</SelectItem>
                        <SelectItem value="manager">Manager</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <span className="px-2 py-1 rounded-full bg-muted/50 text-xs font-medium">
                      {user.role}
                    </span>
                  )}
                </TableCell>
                <TableCell>
                  {editingUserId === user.username ? (
                    <Select
                      defaultValue={user.employee_status}
                      onValueChange={(value) => handleEmployeeStatusChange(user.username, value)}
                    >
                      <SelectTrigger className="w-32 text-sm h-8">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full-time">Full-time</SelectItem>
                        <SelectItem value="part-time">Part-time</SelectItem>
                        <SelectItem value="contract">Contract</SelectItem>
                        <SelectItem value="terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <span className="px-2 py-1 rounded-full bg-muted/50 text-xs font-medium">
                      {user.employee_status || "full-time"}
                    </span>
                  )}
                </TableCell>
                <TableCell>
                  {user.is_admin ? (
                    <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400 text-xs font-medium">
                      Yes
                    </span>
                  ) : (
                    <span className="px-2 py-1 rounded-full bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 text-xs font-medium">
                      No
                    </span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end space-x-2">
                    {editingUserId === user.username ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setEditingUserId(null)}
                        className="h-8 w-8 p-0 rounded-full hover:bg-muted"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    ) : (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditClick(user.username)}
                        className="h-8 w-8 p-0 rounded-full hover:bg-muted"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteUser(user.username)}
                      className="h-8 w-8 p-0 rounded-full text-red-500 hover:bg-red-100 hover:text-red-600 dark:hover:bg-red-900/20"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

    </div>
  );
};

export default UsersContent;
