import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import api from '@/utils/api';
import {
  Activity,
  AlertCircle,
  BookOpen,
  Flag,
  HelpCircle,
  PenTool,
  Trash,
  User
} from "lucide-react";
import { useEffect, useState } from 'react';
import { API_URL } from "@/lib/constants";

interface AccessLog {
  user_id: number;
  username: string;
  user_role: string;
  employee_status: string;
  resource_sensitivity: string;
  action: string;
  access_granted: boolean;
  confidence: number;
  past_violations: number;
  timestamp: string;
}

const ActiveUsers = () => {
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [flagColors, setFlagColors] = useState<Record<number, string>>({});

  useEffect(() => {
    const fetchLogs = async () => {
      try {
        const response = await api(`${API_URL}/access/logs`, {
          method: "GET",
        });
        const data = response;
        const logsData = Array.isArray(data) ? data : [];
        setLogs(logsData);

        // Initialize flag colors based on employee status
        const initialColors: Record<number, string> = {};
        logsData.forEach((log, index) => {
          initialColors[index] = log.employee_status === 'terminated' ? 'red' : 'green';
        });
        setFlagColors(initialColors);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchLogs();

    const interval = setInterval(fetchLogs, 30000);
    return () => clearInterval(interval);
  }, []);

  const toggleFlagColor = (index: number) => {
    setFlagColors((prev) => ({
      ...prev,
      [index]: prev[index] === 'green' ? 'red' : 'green',
    }));
  };

  // Get action icon based on the action type
  const getActionIcon = (action: string) => {
    switch (action) {
      case 'read':
        return <BookOpen className="h-4 w-4" />;
      case 'write':
        return <PenTool className="h-4 w-4" />;
      case 'delete':
        return <Trash className="h-4 w-4" />;
      default:
        return <Activity className="h-4 w-4" />;
    }
  };

  if (loading) return (
    <div className="flex flex-col items-center justify-center p-8 space-y-4">
      <Skeleton className="h-8 w-64 bg-gray-200" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="bg-white border-gray-200 shadow-sm">
            <CardHeader className="pb-2">
              <div className="flex items-center space-x-3">
                <Skeleton className="h-10 w-10 rounded-full bg-gray-200" />
                <div className="space-y-1">
                  <Skeleton className="h-4 w-24 bg-gray-200" />
                  <Skeleton className="h-3 w-16 bg-gray-200" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Skeleton className="h-4 w-full bg-gray-200" />
                <Skeleton className="h-4 w-full bg-gray-200" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  if (error) return (
    <div className="flex items-center justify-center p-8">
      <Card className="bg-white border-red-500 max-w-md w-full">
        <CardHeader>
          <CardTitle className="text-red-500 flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            Something went wrong
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">{error}</p>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <TooltipProvider>
      <div className="p-6 ">
        <div className="flex items-center justify-center gap-2 mb-6">
          <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <User className="h-6 w-6" /> Recent Activity
          </h2>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <HelpCircle className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>This shows your friends who are currently using the app</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {logs.map((log, index) => (
            <Card key={index} className=" border-gray-200 overflow-hidden shadow-sm">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-10 w-10 bg-blue-500">
                      <AvatarFallback className="text-white font-bold">
                        {log.username.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-gray-900">{log.username}</h3>
                      <span className="text-xs text-gray-500">{log.user_role}</span>
                    </div>
                  </div>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleFlagColor(index)}
                        className={`h-8 w-8 rounded-full ${flagColors[index] === 'green' ? 'text-green-500 hover:text-green-400' : 'text-red-500 hover:text-red-400'
                          }`}
                      >
                        <Flag className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Click to change the flag color between green and red</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center justify-between cursor-help">
                        <span className="text-sm text-gray-500">Status:</span>
                        <Badge variant={log.employee_status === 'active' ? 'default' : 'secondary'} className="text-xs">
                          {log.employee_status === 'active' ? 'Online' :
                            log.employee_status === 'terminated' ? 'Gone' : log.employee_status}
                        </Badge>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>This shows if your friend is online right now</p>
                    </TooltipContent>
                  </Tooltip>

                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="flex items-center justify-between cursor-help">
                        <span className="text-sm text-gray-500">Activity:</span>
                        <Badge variant="outline" className="text-xs flex items-center gap-1">
                          {getActionIcon(log.action)}
                          {log.action === 'read' ? 'Reading' :
                            log.action === 'write' ? 'Writing' :
                              log.action === 'delete' ? 'Cleaning up' : log.action}
                        </Badge>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>This shows what your friend is doing right now</p>
                    </TooltipContent>
                  </Tooltip>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </TooltipProvider>
  );
};

export default ActiveUsers;
