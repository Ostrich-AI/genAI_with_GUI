import React, { useEffect, useState } from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import api from "@/utils/api";
import Loading from "@/components/Loading";
import FileUpload from "./FileUpload";
import OtherSources from "./OtherSources";
import ExistingSources from "./ExistingSources";
import { KnowledgeSource, Department, Sensitivity, DEPARTMENTS, SENSITIVITY_LEVELS } from "@/types/knowledge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { API_URL } from "@/lib/constants";

const IngestContent: React.FC = () => {
  const [sources, setSources] = useState<KnowledgeSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notionUrl, setNotionUrl] = useState("");
  const [gdriveUrl, setGdriveUrl] = useState("");
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadedUrls, setUploadedUrls] = useState<string[]>([]);
  const [department, setDepartment] = useState<Department>('IT');
  const [sensitivity, setSensitivity] = useState<Sensitivity>('public');

  const fetchSources = async () => {
    try {
      const response = await api(`${API_URL}/knowledge-sources/knowledge-sources`);
      if (response.data) {
        setSources(response.data);
        setError(null);
      }
    } catch (error) {
      console.error("Failed to fetch sources:", error);
      setError("Failed to load knowledge sources");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSources();
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(Array.from(e.target.files));
    }
  };

  const handleFileUpload = async () => {
    const uploadedFileUrls: string[] = [];
    
    for (const file of selectedFiles) {
      const formData = new FormData();
      formData.append('file', file);

      try {
        const response = await fetch(`${API_URL}/file/upload`, {
          method: 'POST',
          body: formData,
        });

        if (!response.ok) {
          throw new Error(`Upload failed for ${file.name}`);
        }

        const result = await response.json();
        if (result.status === 'success' && result.data?.url) {
          uploadedFileUrls.push(result.data.url);
        }
      } catch (error) {
        console.error(`Error uploading ${file.name}:`, error);
      }
    }

    setUploadedUrls(prev => [...prev, ...uploadedFileUrls]);
    setSelectedFiles([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const notionUrls = notionUrl ? [notionUrl] : [];
    const gdriveUrls = gdriveUrl ? [gdriveUrl] : [];
    
    try {
      await api(`${API_URL}/knowledge-sources/knowledge-sources`, {
        method: "POST",
        body: JSON.stringify({
          notion_urls: notionUrls,
          gdrive_urls: gdriveUrls,
          file_urls: uploadedUrls,
          department,
          sensitivity
        })
      });
      
      // Reset form
      setNotionUrl("");
      setGdriveUrl("");
      setUploadedUrls([]);
      setDepartment('IT');
      setSensitivity('public');
      await fetchSources();
    } catch (error) {
      console.error("Failed to create source:", error);
      setError("Failed to create knowledge source");
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await api(`${API_URL}/knowledge-sources/knowledge-sources/${id}`, {
        method: "DELETE"
      });
      await fetchSources();
    } catch (error) {
      console.error("Failed to delete source:", error);
      setError("Failed to delete knowledge source");
    }
  };

  if (loading) return <Loading />;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <FileUpload
          selectedFiles={selectedFiles}
          uploadedUrls={uploadedUrls}
          onFileSelect={handleFileSelect}
          onUpload={handleFileUpload}
        />

        <Card className="shadow-sm border border-primary/10">
          <CardHeader>
            <CardTitle className="text-xl">Classification</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-6 sm:grid-cols-2">
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Department
              </label>
              <Select
                value={department}
                onValueChange={(value: Department) => setDepartment(value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {DEPARTMENTS.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Sensitivity Level
              </label>
              <Select
                value={sensitivity}
                onValueChange={(value: Sensitivity) => setSensitivity(value)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select sensitivity" />
                </SelectTrigger>
                <SelectContent>
                  {Object.keys(SENSITIVITY_LEVELS).map((level) => (
                    <SelectItem key={level} value={level}>
                      {level.charAt(0).toUpperCase() + level.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <OtherSources
          notionUrl={notionUrl}
          gdriveUrl={gdriveUrl}
          dropboxUrl=""
          onNotionUrlChange={(e) => setNotionUrl(e.target.value)}
          onGdriveUrlChange={(e) => setGdriveUrl(e.target.value)}
          onDropboxUrlChange={() => {}}
        />

        <Button 
          type="submit" 
          className="w-full h-12 text-lg"
          disabled={!uploadedUrls.length && !notionUrl && !gdriveUrl}
        >
          Add Knowledge Source
        </Button>
      </form>

      <ExistingSources
        sources={sources}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default IngestContent; 