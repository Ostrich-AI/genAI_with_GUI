"use client"

import { AreaChart, CartesianGrid, XAxis, Tooltip, Area } from "recharts"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export interface ChartProps {
  title?: string;
  description?: string;
  data?: any[];
  metrics?: string[];
}

export function Chart({
  title = "Data Visualization",
  description = "Showing trend data",
  data = [],
  metrics = ["sales"],
}: ChartProps) {
  // Ensure there's always data to display
  const chartData = data.length > 0 ? data : [
    { month: "January", sales: 100 },
    { month: "February", sales: 200 },
    { month: "March", sales: 150 },
    { month: "April", sales: 300 },
    { month: "May", sales: 250 },
    { month: "June", sales: 400 },
  ];
  
  return (
    <Card className="w-full max-w-[600px]">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-[300px] w-full">
          <AreaChart
            width={500}
            height={300}
            data={chartData}
            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#8884d8" stopOpacity={0.1}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="month" 
              stroke="#888888"
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <CartesianGrid strokeDasharray="3 3" />
            <Tooltip />
            <Area 
              type="monotone" 
              dataKey="sales" 
              stroke="#8884d8" 
              fillOpacity={1} 
              fill="url(#salesGradient)" 
            />
          </AreaChart>
        </div>
      </CardContent>
    </Card>
  );
}
