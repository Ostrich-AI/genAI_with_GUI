import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Handle, Position } from 'reactflow';
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Upload, X } from 'lucide-react';
import api from "@/utils/api";
import { useRouter } from 'next/navigation';
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";

interface NodeData {
  label: string;
  value?: string;
  title?: string;
  description?: string;
  onChange?: (value: string) => void;
  onTitleChange?: (value: string) => void;
  onDescriptionChange?: (value: string) => void;
  agent?: any;
  bot_id?: string;
}

const handleStyle = {
  width: '12px',
  height: '12px',
  border: '2px solid var(--border)',
  backgroundColor: 'var(--background)',
};

const labelStyle = {
  position: 'absolute',
  fontSize: '12px',
  color: 'var(--muted-foreground)',
  userSelect: 'none',
} as const;

const nodeBaseClass = "border rounded-lg shadow-sm min-w-[200px] bg-card text-card-foreground p-4";

export const NotionNode: React.FC<{ data: NodeData }> = ({ data }) => (
  <div className={nodeBaseClass}>
    <Handle type="source" position={Position.Right} style={handleStyle} />
    <Handle type="target" position={Position.Left} style={handleStyle} />
    <div className="space-y-2">
      <h3 className="font-medium text-foreground">{data.label}</h3>
      <Input
        placeholder="Enter Notion URL"
        value={data.value || ''}
        onChange={(e) => data.onChange?.(e.target.value)}
      />
    </div>
  </div>
);

export const GDriveNode: React.FC<{ data: NodeData }> = ({ data }) => (
  <div className={nodeBaseClass}>
    <Handle type="source" position={Position.Right} style={handleStyle} />
    <Handle type="target" position={Position.Left} style={handleStyle} />
    <div className="space-y-2">
      <h3 className="font-medium text-foreground">{data.label}</h3>
      <Input
        placeholder="Enter Google Drive URL"
        value={data.value || ''}
        onChange={(e) => data.onChange?.(e.target.value)}
      />
    </div>
  </div>
);

export const FileUploadNode: React.FC<{ data: NodeData }> = ({ data }) => {
  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles]);
      // Clear the input value to allow selecting the same file again
      e.target.value = '';
    }
  };

  const removeFile = (indexToRemove: number) => {
    setFiles(files.filter((_, index) => index !== indexToRemove));
  };

  return (
    <div className={cn(nodeBaseClass, "min-w-[300px]")}>
      <Handle type="source" position={Position.Right} style={handleStyle} />
      <Handle type="target" position={Position.Left} style={handleStyle} />
      <div className="space-y-4">
        <h3 className="font-medium text-foreground">{data.label}</h3>

        {/* File Input */}
        <div className="space-y-2">
          <input
            type="file"
            multiple
            onChange={handleFileSelect}
            className="hidden"
            ref={fileInputRef}
          />
          <Button
            variant="outline"
            className="w-full"
            onClick={() => fileInputRef.current?.click()}
          >
            Select Files
          </Button>
        </div>

        {/* Files List */}
        {files.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-medium text-foreground">Selected Files:</div>
            <div className="space-y-2 max-h-[200px] overflow-y-auto">
              {files.map((file, index) => (
                <div 
                  key={`${file.name}-${index}`} 
                  className="flex items-center justify-between text-sm bg-muted p-2 rounded"
                >
                  <span className="truncate flex-1 mr-2 text-muted-foreground">
                    {file.name}
                  </span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeFile(index)}
                    className="h-6 w-6 flex-shrink-0 hover:text-destructive"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const AgentDocumentsNode: React.FC<{ data: NodeData }> = ({ data }) => (
  <Card className={cn(nodeBaseClass, "relative min-w-[400px] backdrop-blur-sm bg-card/80")}>
    {/* Input Handle with Label */}
    <div className="absolute -left-24 top-1/2 -translate-y-1/2 flex items-center">
      <span className="text-xs text-muted-foreground font-medium">
        Knowledge Sources
      </span>
      <Handle 
        type="target" 
        position={Position.Left} 
        style={handleStyle}
        className="ml-2"
      />
    </div>
    
    {/* Output Handle with Label */}
    <div className="absolute -right-20 top-1/2 -translate-y-1/2 flex items-center">
      <Handle 
        type="source" 
        position={Position.Right} 
        style={handleStyle}
        className="mr-2"
      />
      <span className="text-xs text-muted-foreground font-medium">
        Config
      </span>
    </div>
    
    <div className="space-y-4">
      <div className="space-y-2">
        <Label className="text-base font-semibold text-primary">
          {data.label}
        </Label>
        <Input
          placeholder="Enter chatbot title..."
          value={data.title || ''}
          onChange={(e) => data.onTitleChange?.(e.target.value)}
          className="bg-background/50 border-muted"
        />
      </div>
      <div className="space-y-2">
        <Label className="text-sm text-muted-foreground">
          Description
        </Label>
        <Textarea
          placeholder="Enter a detailed description of what this chatbot does..."
          value={data.description || ''}
          onChange={(e) => data.onDescriptionChange?.(e.target.value)}
          className="bg-background/50 border-muted min-h-[100px] resize-none"
        />
      </div>
    </div>
  </Card>
);

export const AdditionalDetailsNode: React.FC<{ data: NodeData }> = ({ data }) => (
  <Card className={cn(nodeBaseClass, "min-w-[350px] backdrop-blur-sm bg-card/80")}>
    <Handle 
      type="target" 
      position={Position.Left} 
      style={handleStyle}
      className="ml-2"
    />
    
    <div className="space-y-4">
      <Label className="text-base font-semibold text-primary">
        {data.label}
      </Label>
      <Textarea
        placeholder="Enter any additional configuration, special instructions, or context for the chatbot..."
        value={data.value || ''}
        onChange={(e) => data.onChange?.(e.target.value)}
        className="bg-background/50 border-muted min-h-[150px] resize-none"
      />
    </div>
  </Card>
);
