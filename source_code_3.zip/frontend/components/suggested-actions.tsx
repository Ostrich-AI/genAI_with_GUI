'use client';

import { motion } from 'framer-motion';
import { Button } from './ui/button';
import { memo, useEffect, useState } from 'react';
import { UseChatHelpers } from '@ai-sdk/react';
import { UIMessage } from 'ai';

interface SuggestedActionsProps {
  chatId: string;
  append: UseChatHelpers['append'];
  messages: Array<UIMessage>;
  isFirstMessage?: boolean;
  setInput?: (input: string) => void;
}

// Default suggestions for first-time users
const initialSuggestions = [
  {
    title: 'Draft an email',
    label: 'to the project manager about SDLC progress',
    action: 'Draft an email to pm@company.com about our Agile SDLC implementation progress',
  },
  {
    title: 'Show me a chart',
    label: 'of monthly development progress',
    action: 'Show me a chart of our monthly development progress for the CustomerAssistAI project',
  },
  {
    title: 'Compare Traditional vs Agile',
    label: 'SDLC models for our project',
    action: 'Compare Traditional and Agile SDLC models for our CustomerAssistAI project using text artifact',
  },
  {
    title: 'Explain Scrum',
    label: 'framework activities in detail',
    action: 'Explain Scrum framework activities in detail for our upcoming sprint planning',
  },
];

function PureSuggestedActions({ chatId, append, messages, isFirstMessage = false, setInput }: SuggestedActionsProps) {
  const [suggestedActions, setSuggestedActions] = useState(initialSuggestions);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    // Only fetch auto-suggestions if we have at least one exchange
    // and this isn't the first message view
    if (messages.length >= 2 && !isFirstMessage) {
      setIsLoading(true);
      
      // Get the last assistant message
      const lastAssistantMsg = [...messages]
        .reverse()
        .find(msg => msg.role === 'assistant');
      
      // Function to get suggestions based on conversation context
      const fetchSuggestions = async () => {
        try {
          const response = await fetch('/api/suggestions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              messages: messages.slice(-6), // Last 6 messages for context
              chatId
            }),
          });
          
          if (response.ok) {
            const data = await response.json();
            
            if (data.suggestions && Array.isArray(data.suggestions)) {
              setSuggestedActions(data.suggestions);
            }
          }
        } catch (error) {
          console.error('Failed to fetch auto-suggestions:', error);
          // Fall back to tool-based suggestions if API fails
          setSuggestedActions([
            {
              title: 'Draft an email',
              label: 'based on this conversation',
              action: 'Draft an email summarizing the key points from this conversation',
            },
            {
              title: 'Visualize data',
              label: 'mentioned in our discussion',
              action: 'Create a chart visualizing the data we just discussed',
            },
            {
              title: 'Explain further',
              label: 'with more detail',
              action: 'Please explain the previous response in more detail and provide examples',
            },
            {
              title: 'Summarize',
              label: 'our conversation so far',
              action: 'Please summarize our conversation so far and identify key action items',
            },
          ]);
        } finally {
          setIsLoading(false);
        }
      };
      
      fetchSuggestions();
    }
  }, [messages, chatId, isFirstMessage]);

  // Don't show anything while loading suggestions
  if (isLoading) {
    return (
      <div data-testid="suggested-actions" className="grid sm:grid-cols-2 gap-2 w-full opacity-70">
        {[...Array(4)].map((_, index) => (
          <motion.div
            initial={{ opacity: 0.5 }}
            animate={{ opacity: 1 }}
            transition={{ repeat: Infinity, repeatType: "reverse", duration: 0.8 }}
            key={`loading-suggestion-${index}`}
          >
            <div className="border rounded-xl px-4 py-3.5 h-[60px] animate-pulse bg-muted/30"></div>
          </motion.div>
        ))}
      </div>
    );
  }

  return (
    <div
      data-testid="suggested-actions"
      className="grid sm:grid-cols-2 gap-2 w-full"
    >
      {suggestedActions.map((suggestedAction, index) => (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ delay: 0.05 * index }}
          key={`suggested-action-${suggestedAction.title}-${index}`}
          className={index > 1 ? 'hidden sm:block' : 'block'}
        >
          <Button
            variant="ghost"
            onClick={async () => {
              // If this is the first message and setInput is available, just set the input text
              if (isFirstMessage && setInput) {
                setInput(suggestedAction.action);
              } else {
                // Otherwise perform the normal action
                window.history.replaceState({}, '', `/chat/${chatId}`);
                append({
                  role: 'user',
                  content: suggestedAction.action,
                });
              }
            }}
            className="text-left border rounded-xl px-4 py-3.5 text-sm flex-1 gap-1 sm:flex-col w-full h-auto justify-start items-start"
          >
            <span className="font-medium">{suggestedAction.title}</span>
            <span className="text-muted-foreground">
              {suggestedAction.label}
            </span>
          </Button>
        </motion.div>
      ))}
    </div>
  );
}

export const SuggestedActions = memo(PureSuggestedActions);
