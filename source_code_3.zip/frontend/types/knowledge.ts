export type Department = 
  | 'IT'
  | 'Operations'
  | 'Finance'
  | 'Legal'
  | 'Sales'
  | 'Engineering'
  | 'HR';

export type Sensitivity = 'public' | 'confidential' | 'restricted';

export interface KnowledgeSource {
  id: number;
  user_id: number;
  notion_urls: string[];
  gdrive_urls: string[];
  file_urls: string[];
  department: Department;
  sensitivity: Sensitivity;
  created_at: string;
  updated_at: string;
}

export const DEPARTMENTS: Department[] = [
  'IT',
  'Operations',
  'Finance',
  'Legal',
  'Sales',
  'Engineering',
  'HR'
];

export const SENSITIVITY_LEVELS: { [key in Sensitivity]: number } = {
  'public': 0,
  'confidential': 1,
  'restricted': 2
}; 