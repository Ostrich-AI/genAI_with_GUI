// types/user.ts
export interface User {
    id: number;
    username: string;
    role: string;
    is_admin: boolean;
    employee_status: string;
    // Add other user properties as needed
  }
  