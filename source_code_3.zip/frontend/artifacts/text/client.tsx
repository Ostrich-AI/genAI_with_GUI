import { Artifact } from '@/components/create-artifact';
import { DiffView } from '@/components/diffview';
import { DocumentSkeleton } from '@/components/document-skeleton';
import { Editor } from '@/components/text-editor';
import {
  ClockRewind,
  CopyIcon,
  MessageIcon,
  PenIcon,
  RedoIcon,
  UndoIcon,
} from '@/components/icons';
import { toast } from 'sonner';
import dynamic from 'next/dynamic';
import { DownloadIcon } from 'lucide-react'; // Import DownloadIcon from lucide-react

// Import Chart component with dynamic import to avoid SSR issues
const ChartComponent = dynamic(() => import('@/app/chart/page'), {
  ssr: false,
  loading: () => <div className="h-[300px] w-full bg-muted animate-pulse rounded-md"></div>
});

interface TextArtifactMetadata {
  suggestions: Array<any>;
  showChart?: boolean;
  chartData?: any;
}

// Parse chart data from content
function parseChartData(content: string) {
  const chartRegex = /```chart\s*([\s\S]*?)\s*```/;
  const match = content.match(chartRegex);
  
  if (match && match[1]) {
    try {
      return JSON.parse(match[1]);
    } catch (e) {
      console.error("Failed to parse chart data:", e);
      return null;
    }
  }
  return null;
}

// Function to download content as a markdown file
function downloadAsMarkdown(content: string, filename = 'document.md') {
  // Create a blob with the content
  const blob = new Blob([content], { type: 'text/markdown' });
  
  // Create a URL for the blob
  const url = URL.createObjectURL(blob);
  
  // Create a temporary anchor element
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  
  // Append to the body, click, and remove
  document.body.appendChild(a);
  a.click();
  
  // Clean up
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 100);
}

export const textArtifact = new Artifact<'text', TextArtifactMetadata>({
  kind: 'text',
  description: 'Useful for text content, like drafting essays and emails.',
  initialize: async ({ setMetadata }) => {
    setMetadata({
      suggestions: [],
      showChart: true,
      chartData: null
    });
  },
  onStreamPart: ({ streamPart, setMetadata, setArtifact }) => {
    if (streamPart.type === 'suggestion') {
      setMetadata((metadata) => {
        return {
          ...metadata,
          suggestions: [...(metadata?.suggestions ?? []), streamPart.content],
        };
      });
    }

    if (streamPart.type === 'text-delta') {
      setArtifact((draftArtifact) => {
        const newContent = draftArtifact.content + (streamPart.content as string);
        
        // Check if complete content includes chart data
        const chartData = parseChartData(newContent);
        if (chartData) {
          setMetadata((metadata) => ({
            ...metadata,
            chartData
          }));
          
          // Remove chart data from content
          const cleanContent = newContent.replace(/```chart\s*([\s\S]*?)\s*```/, '');
          return {
            ...draftArtifact,
            content: cleanContent,
            isVisible:
              draftArtifact.status === 'streaming' &&
              cleanContent.length > 400 &&
              cleanContent.length < 450
                ? true
                : draftArtifact.isVisible,
            status: 'streaming',
          };
        }
        
        return {
          ...draftArtifact,
          content: newContent,
          isVisible:
            draftArtifact.status === 'streaming' &&
            newContent.length > 400 &&
            newContent.length < 450
              ? true
              : draftArtifact.isVisible,
          status: 'streaming',
        };
      });
    }
  },
  content: ({
    mode,
    status,
    content,
    isCurrentVersion,
    currentVersionIndex,
    onSaveContent,
    getDocumentContentById,
    isLoading,
    metadata,
  }) => {
    if (isLoading) {
      return <DocumentSkeleton artifactKind="text" />;
    }

    if (mode === 'diff') {
      const oldContent = getDocumentContentById(currentVersionIndex - 1);
      const newContent = getDocumentContentById(currentVersionIndex);

      return <DiffView oldContent={oldContent} newContent={newContent} />;
    }

    return (
      <>
        <div className="flex flex-col py-8 md:p-20 px-4 w-full">
          {/* {metadata?.showChart && (
            <div className="mb-8 w-full">
              <ChartComponent 
                title={metadata?.chartData?.title || "Data Visualization"}
                description={metadata?.chartData?.description || "Automatically generated from your content"}
                data={metadata?.chartData?.data}
                metrics={metadata?.chartData?.metrics}
                footer={metadata?.chartData?.footer}
                trend={metadata?.chartData?.trend}
              />
            </div>
          )} */}
          
          <Editor
            content={content}
            suggestions={metadata?.suggestions ?? []}
            isCurrentVersion={isCurrentVersion}
            currentVersionIndex={currentVersionIndex}
            status={status}
            onSaveContent={onSaveContent}
          />

          {metadata?.suggestions && metadata.suggestions.length > 0 ? (
            <div className="md:hidden h-dvh w-12 shrink-0" />
          ) : null}
        </div>
      </>
    );
  },
  actions: [
    {
      icon: <ClockRewind size={18} />,
      description: 'View changes',
      onClick: ({ handleVersionChange }) => {
        handleVersionChange('toggle');
      },
      isDisabled: ({ currentVersionIndex, setMetadata }) => {
        if (currentVersionIndex === 0) {
          return true;
        }

        return false;
      },
    },
    {
      icon: <UndoIcon size={18} />,
      description: 'View Previous version',
      onClick: ({ handleVersionChange }) => {
        handleVersionChange('prev');
      },
      isDisabled: ({ currentVersionIndex }) => {
        if (currentVersionIndex === 0) {
          return true;
        }

        return false;
      },
    },
    {
      icon: <RedoIcon size={18} />,
      description: 'View Next version',
      onClick: ({ handleVersionChange }) => {
        handleVersionChange('next');
      },
      isDisabled: ({ isCurrentVersion }) => {
        if (isCurrentVersion) {
          return true;
        }

        return false;
      },
    },
    {
      icon: <DownloadIcon size={18} />, // Changed from CopyIcon to DownloadIcon
      description: 'Download as Markdown', // Changed description
      onClick: ({ content }) => {
        // Generate a filename based on the first line (title) or default
        let filename = 'document.md';
        const firstLine = content.split('\n')[0];
        if (firstLine && firstLine.trim()) {
          // Remove markdown heading symbols and clean up for filename
          filename = firstLine.replace(/^#+\s+/, '').trim().slice(0, 50)
            .replace(/[^\w\s-]/g, '') // Remove special chars
            .replace(/\s+/g, '-') // Replace spaces with hyphens
            .toLowerCase() + '.md';
        }
        
        downloadAsMarkdown(content, filename);
        toast.success('Downloaded as Markdown!');
      },
    },
  ],
  toolbar: [
    {
      icon: <PenIcon />,
      description: 'Add final polish',
      onClick: ({ appendMessage }) => {
        appendMessage({
          role: 'user',
          content:
            'Please add final polish and check for grammar, add section titles for better structure, and ensure everything reads smoothly.',
        });
      },
    },
    {
      icon: <MessageIcon />,
      description: 'Request suggestions',
      onClick: ({ appendMessage }) => {
        appendMessage({
          role: 'user',
          content:
            'Please add suggestions you have that could improve the writing.',
        });
      },
    },
  ],
});
