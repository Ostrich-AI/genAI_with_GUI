"use client";
import React, {
    createContext,
    useState,
    useEffect,
    useContext,
    useCallback,
} from "react";
import { jwtDecode } from "jwt-decode";
import { useRouter, usePathname } from "next/navigation";

interface User {
    username: string;
    is_admin: boolean;
    id?: number;
    role: string;
    employee_status: string;
}

interface AuthContextType {
    token: string | null;
    user: User | null;
    loading: boolean;
    login: (username: string, password: string) => Promise<void>;
    register: (username: string, password: string) => Promise<void>;
    logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

interface AuthProviderProps {
    children: React.ReactNode;
    loginRoute?: string;
    registerRoute?: string;
    meRoute?: string;
    signInRoute?: string;
    redirectRoute?: string;
}

const AuthProvider = ({
    children,
    loginRoute = "/auth/login",
    registerRoute = "/users/",
    meRoute = "/auth/me",
    signInRoute = "/signin",
    redirectRoute = "/home",
}: AuthProviderProps) => {
    const [token, setToken] = useState<string | null>(
        typeof window !== "undefined" ? localStorage.getItem("token") || null : null
    );
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        const validateToken = async () => {
            setLoading(true);
            if (token) {
                try {
                    const decodedToken = jwtDecode<{
                        exp?: number;
                        username: string;
                        is_admin: boolean;
                    }>(token);
                    console.log("Decoded token:", decodedToken);

                    if ((decodedToken.exp ?? 0) * 1000 < Date.now()) {
                        setToken(null);
                        setUser(null);
                        localStorage.removeItem("token");
                        router.push(signInRoute);
                    } else {
                        const response = await fetch(meRoute, {
                            headers: {
                                Authorization: `Bearer ${token}`,
                            },
                        });

                        if (response.ok) {
                            const userData: User = await response.json();
                            setUser({
                                username: userData.username,
                                is_admin: userData.is_admin,
                                role: userData.role,
                                id: userData.id,
                                employee_status: userData.employee_status
                            });

                            // Redirect to home if on auth pages
                            if (pathname === signInRoute || pathname === "/login") {
                                router.push(redirectRoute);
                            }
                        } else {
                            setToken(null);
                            setUser(null);
                            localStorage.removeItem("token");
                            router.push(signInRoute);
                        }
                    }
                } catch (error) {
                    console.error("Error decoding/fetching user:", error);
                    setToken(null);
                    setUser(null);
                    localStorage.removeItem("token");
                    router.push(signInRoute);
                }
            } else {
                // Only redirect to signin if not already on auth pages
                if (pathname !== signInRoute && pathname !== "/login") {
                    router.push(signInRoute);
                }
            }
            setLoading(false);
        };

        validateToken();
    }, [token, router, loginRoute, registerRoute, meRoute, signInRoute, redirectRoute, pathname]);

    const login = useCallback(
        async (username: string, password: string) => {
            try {
                const response = await fetch(loginRoute, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: `username=${username}&password=${password}`,
                });

                if (response.ok) {
                    const data = await response.json();
                    const newToken = data.access_token;
                    localStorage.setItem("token", newToken);
                    setToken(newToken);
                    router.push(redirectRoute);
                } else {
                    console.error("Login failed:", response.status);
                    throw new Error("Login failed");
                }
            } catch (error) {
                console.error("Login error:", error);
                throw error;
            }
        },
        [loginRoute, router, redirectRoute]
    );

    const register = useCallback(
        async (username: string, password: string) => {
            try {
                const response = await fetch(
                    `${registerRoute}?username=${username}&password=${password}`,
                    {
                        method: "POST",
                        headers: {
                            accept: "application/json",
                            "Content-Type": "application/json",
                        },
                        body: JSON.stringify({}),
                    }
                );

                if (response.ok) {
                    console.log("Registration successful");
                    router.push("/login");
                } else {
                    console.error("Registration failed:", response.status);
                    throw new Error("Registration failed");
                }
            } catch (error) {
                console.error("Registration error:", error);
                throw error;
            }
        },
        [registerRoute, router]
    );

    const logout = useCallback(() => {
        setToken(null);
        setUser(null);
        localStorage.removeItem("token");
        router.push(signInRoute);
    }, [router, signInRoute]);

    const value: AuthContextType = {
        token,
        user,
        loading,
        login,
        register,
        logout,
    };

    return (
        <AuthContext.Provider value={value}>
            {!loading && children}
        </AuthContext.Provider>
    );
};

const useUser = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useUser must be used within an AuthProvider");
    }
    return context;
};

export { AuthProvider, useUser };
