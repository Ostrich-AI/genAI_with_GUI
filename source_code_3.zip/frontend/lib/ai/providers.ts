import {
  customProvider,
  extractReasoningMiddleware,
  wrapLanguageModel,
} from 'ai';
import { groq } from '@ai-sdk/groq';
import { xai } from '@ai-sdk/xai';
import {google} from '@ai-sdk/google'

export const myProvider = customProvider({
  languageModels: {
    'chat-model': google('gemini-2.0-flash-001'),
    'chat-model-reasoning': wrapLanguageModel({
      model: groq('deepseek-r1-distill-llama-70b'),
      middleware: extractReasoningMiddleware({ tagName: 'think' }),
    }),
    'title-model': google('gemini-2.0-flash-001'),
    'artifact-model': google('gemini-2.0-flash-001'),
  },
  imageModels: {
    'small-model': xai.image('grok-2-image'),
  },
});
