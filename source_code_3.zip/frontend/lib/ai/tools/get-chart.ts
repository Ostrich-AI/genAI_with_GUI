import { tool } from 'ai';
import { z } from 'zod';

export const generateChart = tool({
  description: 'Generate a line chart visualizing data trends',
  parameters: z.object({
    title: z.string().describe("Chart title"),
    description: z.string().describe("Chart description"),
    // Simplify by using fixed values for xAxis and metrics
    data: z.array(
      z.object({
        month: z.string().describe("Month or time period label"),
        sales: z.number().describe("Sales value for the month"),
      })
    ).describe("Array of data points with month and sales values"),
  }),
  execute: async ({ title, description, data }) => {
    // Simplified processing - just ensure we have properly formatted data
    const processedData = data.map(item => ({
      month: String(item.month || ""), // Ensure month is a string
      sales: typeof item.sales === 'number' ? item.sales : 0 // Ensure sales is a number
    }));

    // Return simplified data for the Chart component
    return {
      title,
      description,
      data: processedData,
      metrics: ["sales"], // Fixed metric
      // No footer or trend needed
    };
  },
});