import { z } from 'zod';
import { DataStreamWriter, streamObject, tool } from 'ai';
import { generateUUID } from '@/lib/utils';
import { myProvider } from '../providers';

interface RequestSuggestionsProps {
  dataStream: DataStreamWriter;
}

export const requestSuggestions = ({
  dataStream,
}: RequestSuggestionsProps) =>
  tool({
    description: 'Request suggestions for improving a piece of text content.',
    parameters: z.object({
      documentId: z.string().describe('The ID associated with the document content in the UI'),
      documentContent: z.string().describe('The text content of the document to get suggestions for'),
    }),
    execute: async ({ documentId, documentContent }) => {
      const { elementStream } = streamObject({
        model: myProvider.languageModel('artifact-model'),
        system:
          'You are a help writing assistant. Given a piece of writing, please offer suggestions to improve the piece of writing and describe the change. It is very important for the edits to contain full sentences instead of just words. Max 5 suggestions.',
        prompt: documentContent,
        output: 'array',
        schema: z.object({
          originalSentence: z.string().describe('The original sentence'),
          suggestedSentence: z.string().describe('The suggested sentence'),
          description: z.string().describe('The description of the suggestion'),
        }),
      });

      for await (const element of elementStream) {
        const suggestion = {
          originalText: element.originalSentence,
          suggestedText: element.suggestedSentence,
          description: element.description,
          id: generateUUID(),
          documentId: documentId,
        };

        dataStream.writeData({
          type: 'suggestion',
          content: suggestion,
        });
      }

      return {
        message: 'Suggestions generated and streamed.',
        documentId: documentId,
      };
    },
  });
