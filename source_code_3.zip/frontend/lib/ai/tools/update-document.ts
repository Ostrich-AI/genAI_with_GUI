import { DataStreamWriter, tool } from 'ai';
import { z } from 'zod';
import { documentHandlersByArtifactKind, artifactKinds } from '@/lib/artifacts/server';

interface UpdateDocumentProps {
  dataStream: DataStreamWriter;
}

const artifactKindEnum = z.enum(artifactKinds);

export const updateDocument = ({ dataStream }: UpdateDocumentProps) =>
  tool({
    description: 'Update the content of an existing artifact based on a description.',
    parameters: z.object({
      id: z.string().describe('The ID associated with the artifact in the UI'),
      documentKind: artifactKindEnum.describe("The kind of the artifact (e.g., 'text', 'code')"),
      documentTitle: z.string().describe('The current title of the artifact'),
      documentContent: z.string().describe('The current content of the artifact to be updated'),
      description: z
        .string()
        .describe('A description of the changes or updates needed for the artifact content'),
    }),
    execute: async ({ id, documentKind, documentTitle, documentContent, description }) => {
      dataStream.writeData({
        type: 'clear',
        content: documentTitle,
      });

      const documentHandler = documentHandlersByArtifactKind.find(
        (handler) => handler.kind === documentKind,
      );

      if (!documentHandler) {
        console.error(`No document handler found for kind: ${documentKind}`);
        dataStream.writeData({ type: 'error', content: `Unsupported artifact kind: ${documentKind}` });
        return {
          error: `Unsupported artifact kind: ${documentKind}`,
        };
      }

      const simplifiedDocument = {
        id: id,
        title: documentTitle,
        kind: documentKind,
        content: documentContent,
      };

      await documentHandler.onUpdateDocument({
        document: simplifiedDocument,
        description,
        dataStream,
      });

      dataStream.writeData({ type: 'finish', content: '' });

      return {
        id,
        title: documentTitle,
        kind: documentKind,
        message: 'The artifact has been updated.',
      };
    },
  });
