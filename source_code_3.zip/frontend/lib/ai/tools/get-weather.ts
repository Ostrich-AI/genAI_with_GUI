import { tool } from 'ai';
import { z } from 'zod';

export const getWeather = tool({
  description: 'Get the current weather at a location',
  parameters: z.object({
    latitude: z.number(),
    longitude: z.number(),
  }),
  execute: async ({ latitude, longitude }) => {
    const response = await fetch(
      `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m&hourly=temperature_2m&daily=sunrise,sunset&timezone=auto`,
    );
    const weatherData = await response.json();
    return weatherData;
  },
});

export const draftEmail = tool({
  description: 'Draft an email with given context and recipient information',
  parameters: z.object({
    recipient: z.string(),
    subject: z.string(),
    contextForBody: z.string(),
    senderEmail: z.string().optional(),
    actionType: z.literal('draftEmail'),
  }),
  execute: async ({ recipient, subject, contextForBody, senderEmail }) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const validatedRecipient = emailRegex.test(recipient) ? recipient : '';
    const validatedSender = senderEmail && emailRegex.test(senderEmail) ? senderEmail : '';

    return {
      to: validatedRecipient,
      subject,
      body: contextForBody,
      from: validatedSender,
      timestamp: new Date().toISOString(),
    };
  },
});
