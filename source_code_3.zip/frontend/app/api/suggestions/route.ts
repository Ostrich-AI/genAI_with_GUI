import { suggestionPrompt } from '@/lib/ai/prompts';
import { myProvider } from '@/lib/ai/providers';
import { generateUUID } from '@/lib/utils';

export async function POST(request: Request) {
  try {
    const { messages } = await request.json();

    // Prepare system message with suggestion prompt
    const systemMessage = {
      id: generateUUID(),
      role: 'system',
      content: suggestionPrompt,
    };
    
    // Get suggestions from AI - use 'chat-model' which is defined in your providers.ts
    // Using the correct method for generation - Google models use generate() not doGenerate()
    const response = await myProvider.languageModel('chat-model').generate({
      // Format messages correctly for Google model
      messages: [
        {
          role: "system",
          content: suggestionPrompt
        },
        ...messages.slice(-5).map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      ]
    });

    // Parse suggestions from response
    let suggestions = [];
    try {
      // Attempt to parse JSON from the completion
      const completionText = response.text || "";
      const jsonMatch = completionText.match(/\[[\s\S]*\]/);
      
      if (jsonMatch) {
        suggestions = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No valid JSON array found in response');
      }
    } catch (error) {
      console.error('Failed to parse suggestions:', error);
      // Fallback suggestions if parsing fails
      suggestions = [
        {
          title: "Draft an email",
          label: "based on our conversation",
          action: "Draft an email summarizing the key points from our conversation"
        },
        {
          title: "Create a chart",
          label: "with relevant data",
          action: "Create a chart showing the data we've discussed" 
        },
        {
          title: "Explain further",
          label: "with more detail",
          action: "Can you explain your last point in more detail with examples?"
        },
        {
          title: "Summarize",
          label: "what we've discussed",
          action: "Please summarize what we've discussed so far"
        }
      ];
    }

    return new Response(JSON.stringify({ suggestions }), {
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    console.error('Error generating suggestions:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to generate suggestions',
      suggestions: [
        {
          title: "Draft an email",
          label: "based on our conversation",
          action: "Draft an email summarizing the key points from our conversation"
        },
        {
          title: "Create a chart",
          label: "with relevant data",
          action: "Create a chart showing the data we've discussed" 
        },
        {
          title: "Explain further",
          label: "with more detail",
          action: "Can you explain your last point in more detail with examples?"
        },
        {
          title: "Summarize",
          label: "what we've discussed",
          action: "Please summarize what we've discussed so far"
        }
      ]
    }), {
      status: 200, // Changed from 500 to 200 to still return fallback suggestions
      headers: { 'Content-Type': 'application/json' }
    });
  }
} 