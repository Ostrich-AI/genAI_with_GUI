    // frontend/app/home/ingest/page.tsx
    "use client";
    import IngestContent from "@/components/dashboard/IngestContent";
    import RequireAuth from "@/components/RequireAuth"; // Or admin-specific auth
    import { useUser } from "@/providers/AppProvider";
    import Loading from "@/components/Loading";


    export default function IngestPage() {
      const { user, loading } = useUser();

      if (loading) return <Loading />;
      if (!user?.is_admin) return <RequireAuth />; // Protect route

      return <IngestContent />;
    }