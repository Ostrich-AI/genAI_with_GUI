    // frontend/app/home/users/page.tsx
    "use client";
    import UsersContent from "@/components/dashboard/UsersContent";
    import RequireAuth from "@/components/RequireAuth"; // Or admin-specific auth
    import { useUser } from "@/providers/AppProvider";
    import Loading from "@/components/Loading";

    export default function UsersPage() {
      const { user, loading } = useUser();

      if (loading) return <Loading />;
      if (!user?.is_admin) return <RequireAuth />; // Protect route

      return <UsersContent />;
    }