    // frontend/app/home/pro-mode/page.tsx
    "use client";
    import ProModeContent from "@/components/dashboard/ProModeContent";
    import RequireAuth from "@/components/RequireAuth"; // Or admin-specific auth
    import { useUser } from "@/providers/AppProvider";
    import Loading from "@/components/Loading";

    export default function ProModePage() {
      const { user, loading } = useUser();

      if (loading) return <Loading />;
      if (!user?.is_admin) return <RequireAuth />; // Protect route

      return <ProModeContent />;
    }