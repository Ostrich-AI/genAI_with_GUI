"use client";
import { useState, useEffect } from "react";
import RequireAuth from "@/components/RequireAuth";
import { useUser } from "@/providers/AppProvider";
import api from "@/utils/api";
import DashboardContent from "@/components/dashboard/DashboardContent";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, User as UserIcon, LogOut, RocketIcon } from "lucide-react";
import { User } from "@/types/user";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import Loading from "@/components/Loading";
import { API_URL } from "@/lib/constants";

function HomePage() {
  const { user, loading, logout } = useUser();
  const [userData, setUserData] = useState<any>(null);

  useEffect(() => {
    const _id = setTimeout(async () => {
      try {
        const data = await api(`${API_URL}/auth/me`);
        setUserData(data);
        console.log(data);
      } catch (error) {
        console.error("Failed to fetch user data:", error);
      }
    }, 100);

    return () => {
      clearTimeout(_id);
    };
  }, []);

  if (loading) {
    return <Loading />;
  }

  if (!user) {
    return <RequireAuth />;
  }

  if (!user.is_admin) {
    return (
      <div className="min-h-screen mt-10">
        <div className="max-w-4xl mx-auto space-y-6">
          <Card className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <UserIcon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <CardTitle>{user.username}</CardTitle>
                  <CardDescription>Regular User</CardDescription>
                </div>
              </div>
              <Button variant="outline" onClick={logout} className="flex items-center space-x-2">
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </Button>
            </CardHeader>
          </Card>

          <Link href="/" className="block">
            <Button
              variant="outline"
              className="w-full h-20 rounded-xl relative group overflow-hidden border-0"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="absolute inset-[1px] bg-background rounded-xl" />
              <div className="relative flex items-center justify-center space-x-3">
                <RocketIcon className="h-8 w-8 text-primary" />
                <span className="text-xl font-semibold">Launch Chatbot</span>
              </div>
            </Button>
          </Link>

          <Tabs defaultValue="profile" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="profile">
              <Card>
                <CardHeader>
                  <CardTitle>User Information</CardTitle>
                  <CardDescription>Your account details and preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Username</p>
                      <p className="text-lg">{user.username}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Role</p>
                      <Badge variant="secondary">{user.role}</Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Employee Status</p>
                      <Badge variant="outline">{user.employee_status}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Manage your account preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-medium">Security</h3>
                      <p className="text-sm text-muted-foreground">Manage your account security settings</p>
                    </div>
                    <Button variant="outline" className="w-full">
                      Change Password
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  }

  return (
    <>
      <DashboardContent />
    </>
  );
}

export default HomePage;

