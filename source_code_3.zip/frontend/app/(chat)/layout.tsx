"use client";
import { AppSidebar } from '@/components/app-sidebar';
import { SidebarInset, SidebarProvider } from '@/components/ui/sidebar';
import Script from 'next/script';
import { Glow } from '@/components/glow';
import { useUser } from '@/providers/AppProvider';

export const experimental_ppr = true;

export default function Layout({
  children,
}: {
  children: React.ReactNode;
}) {

  const { user } = useUser();

  const isCollapsed = false;

  return (
    <>

      <Script
        src="https://cdn.jsdelivr.net/pyodide/v0.23.4/full/pyodide.js"
        strategy="beforeInteractive"
      />
      <SidebarProvider defaultOpen={!isCollapsed}>
        {user && user.is_admin && <AppSidebar />}
        <SidebarInset>{children}</SidebarInset>
      </SidebarProvider>

    </>
  );
}
