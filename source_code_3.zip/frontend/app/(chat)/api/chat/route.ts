import { systemPrompt } from '@/lib/ai/prompts';
import { myProvider } from '@/lib/ai/providers';
import { createDocument } from '@/lib/ai/tools/create-document';
import { getWeather, draftEmail } from '@/lib/ai/tools/get-weather';
import { requestSuggestions } from '@/lib/ai/tools/request-suggestions';
import { updateDocument } from '@/lib/ai/tools/update-document';
import { isProductionEnvironment, API_URL } from '@/lib/constants';
import {
  generateUUID,
  getMostRecentUserMessage
} from '@/lib/utils';
import {
  UIMessage,
  createDataStreamResponse,
  smoothStream,
  streamText
} from 'ai';
import { generateChart } from '@/lib/ai/tools/get-chart';

export const maxDuration = 100;

export async function POST(request: Request) {
  try {
    const {
      messages,
      selectedChatModel,
    }: {
      messages: Array<UIMessage>;
      selectedChatModel: string;
    } = await request.json();

    const userMessage = getMostRecentUserMessage(messages);

    if (!userMessage) {
      return new Response('No user message found', { status: 400 });
    }

    // Fetch RAG results
    // Check if the system message is already present
    const systemMessageContent =
      `You must NEVER use code blocks for formatting responses. 
      All citations must be inline hyperlinks. 
      Format citations as [number](URL) directly in the text. 
      if you wat to cite 1 document use [number](URL) format along with footer citations.
      If you want to cite multiple documents, use [number1](URL) [number2](URL) format for each document.
      Ensure all sources are properly cited with working links 
      and also use footnotes for citations. Do not use backticks or markdown-like blocks. 
      If you want to show something as is, use the text artifact. 
      Do not update documents immediately after creating them. Wait for user feedback or request to update it.`;
    const hasSystemMessage = messages.some(
      (msg) => msg.role === 'system' && msg.content === systemMessageContent
    );

    // Add the system message as the first message if not present
    const messagesWithSystemPrompt = hasSystemMessage
      ? messages
      : [
        {
          id: generateUUID(),
          role: 'system',
          content: systemMessageContent,
        },
        ...messages,
      ];

    var messagesWithRAG = messagesWithSystemPrompt;

    const msg = userMessage.content.toLowerCase().trim();
    if (
      msg.split(' ').length < 4 ||
      msg.includes('artifact') ||
      msg.includes('generate') ||
      msg.includes('report') ||
      msg.includes('sheet') ||
      msg.includes('image') ||
      msg.includes('show') ||
      msg.includes('create')
    ) {
      // Skip RAG for short queries or specific commands
    } else {
      const response = await fetch(`${API_URL}/rag/query`, {
        method: 'POST',
        body: JSON.stringify({ question: userMessage.content }),
        headers: {
          'Content-Type': 'application/json',
        },
      }).then((res) => res.json());

      const ragOutput = response.response;
      const sources = response.metadata.source_files;

      console.log('RAG output:', ragOutput, response);

      // Create a new array with the RAG context as an assistant message
      messagesWithRAG = [
        ...messagesWithSystemPrompt.slice(0, -1), // All messages except the last user message
        userMessage,
        {
          id: generateUUID(),
          role: 'assistant',
          content: `I found relevant information for your query. I'll use this to provide a comprehensive answer.

CRITICAL FORMATTING INSTRUCTIONS:
1. NEVER use code blocks or markdown formatting that would break hyperlinks
2. ALL citations must be inline hyperlinks formatted as [number](URL)
3. Citations should appear directly after the relevant text
4. DO NOT add introductory phrases like "Based on the provided documents..."
5. Every word must provide value - no filler text
6. Use artifacts for tables and structured information when appropriate

Here's the information I found:

${ragOutput}

Sources:
${JSON.stringify(sources, null, 2)}

I will now provide a direct, concise answer that cites these sources properly. If the information is not relevant, I will ignore it and provide a direct answer to your question. Starting with "As per my knowledge"  and with appropriate disclaimers.`,
        },
      ];
    }

    // Add an enhanced system prompt to the beginning that strongly enforces formatting rules
    const enhancedSystemPrompt = `${systemPrompt({ selectedChatModel })}

CRITICAL FORMATTING REQUIREMENTS:
- You are STRICTLY FORBIDDEN from using code blocks in your response
- All citations MUST be formatted as inline hyperlinks [number](URL)
- If you use code blocks, you will break the citation links
- Respond in plain text with inline citations only
- Failure to follow these instructions will result in unusable output
- Every word must provide direct value to the user`;

    return createDataStreamResponse({
      execute: (dataStream) => {
        const result = streamText({
          model: myProvider.languageModel(selectedChatModel),
          system: enhancedSystemPrompt,
          messages: messagesWithRAG,
          maxSteps: 5,
          experimental_activeTools:
            selectedChatModel === 'chat-model-reasoning'
              ? []
              : [
                'getWeather',
                'createDocument',
                'updateDocument',
                'requestSuggestions',
                'draftEmail',
                'generateChart',
              ],
          experimental_transform: smoothStream({ chunking: 'word' }),
          experimental_generateMessageId: generateUUID,
          tools: {
            getWeather,
            createDocument: createDocument({ dataStream }),
            updateDocument: updateDocument({ dataStream }),
            requestSuggestions: requestSuggestions({
              dataStream,
            }),
            draftEmail,
            generateChart,
          },
          experimental_telemetry: {
            isEnabled: isProductionEnvironment,
            functionId: 'stream-text',
          },
        });

        result.consumeStream();

        result.mergeIntoDataStream(dataStream, {
          sendReasoning: true,
        });
      },
      onError: (error) => {
        console.error('Error in chat stream:', error);
        return 'Oops, an error occurred!';
      },
    });
  } catch (error) {
    console.error('POST request failed:', error);
    return new Response('An error occurred while processing your request!', {
      status: 500,
    });
  }
}
