import { cookies } from 'next/headers';
// Removed: import { notFound } from 'next/navigation';

// Removed: import { auth } from '@/app/(auth)/auth';
import { Chat } from '@/components/chat';
// Removed DB imports:
// import { getChatById, getMessagesByChatId } from '@/lib/db/queries';
import { DataStreamHandler } from '@/components/data-stream-handler';
import { DEFAULT_CHAT_MODEL } from '@/lib/ai/models';
// Removed DB Message type: import { DBMessage } from '@/lib/db/schema';
// Removed: import { Attachment, UIMessage } from 'ai'; // UIMessage might still be needed by Chat component, keep if so
import type { UIMessage } from 'ai'; // Keep if Chat component needs it
import { Glow } from '@/components/glow';

export default async function Page(props: { params: Promise<{ id: string }> }) {
  // Get ID directly from params
  const { id } = await props.params;

  // Removed: Fetching chat and messages from DB
  // const chat = await getChatById({ id });
  // if (!chat) { notFound(); }

  // Removed: Session fetching and auth/visibility checks
  // const session = await auth();
  // if (chat.visibility === 'private') { ... }

  // Removed: Fetching messages from DB
  // const messagesFromDb = await getMessagesByChatId({ id });

  // Removed: DB to UI message conversion function
  // function convertToUIMessages(...) { ... }

  const cookieStore = await cookies();
  const chatModelFromCookie = cookieStore.get('chat-model');
  const selectedChatModel = chatModelFromCookie?.value ?? DEFAULT_CHAT_MODEL;

  // Render the Chat component directly, passing the ID from the URL
  // and starting with empty messages.
  return (
    <>
    
      <Chat
        id={id} // Use ID from URL param
        initialMessages={[]} // Start with empty messages
        selectedChatModel={selectedChatModel}
        // selectedVisibilityType={'private'} // Removed or hardcoded
        isReadonly={false} // Chat is never read-only now
      />
      {/* DataStreamHandler likely handles client-side streaming updates */}
      <DataStreamHandler id={id} />
    </>
  );

  /* // Removed the conditional rendering based on cookie existence, simplified above
  if (!chatModelFromCookie) {
    // ... old block ...
  }

  return (
    // ... old block ...
  );
  */
}
