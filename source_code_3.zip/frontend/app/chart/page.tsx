"use client"

import { TrendingUp } from "lucide-react"
import { Area, AreaChart, CartesianGrid, XAxis } from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"

export interface ChartProps {
  title?: string;
  description?: string;
  data?: any[];
  metrics?: string[];
  footer?: string;
  trend?: {
    value: string;
    period: string;
  };
}

// Default data if none provided
const defaultChartData = [
  { month: "January", desktop: 186, mobile: 80 },
  { month: "February", desktop: 305, mobile: 200 },
  { month: "March", desktop: 237, mobile: 120 },
  { month: "April", desktop: 73, mobile: 190 },
  { month: "May", desktop: 209, mobile: 130 },
  { month: "June", desktop: 214, mobile: 140 },
]

const defaultChartConfig = {
  desktop: {
    label: "Desktop",
    color: "hsl(var(--chart-1))",
  },
  mobile: {
    label: "Mobile",
    color: "hsl(var(--chart-2))",
  },
}

export default function Chart({
  title = "Area Chart - Stacked",
  description = "Showing total visitors for the last 6 months",
  data = defaultChartData,
  metrics = ["desktop", "mobile"],
  footer = "January - June 2024",
  trend = { value: "5.2%", period: "this month" }
}: ChartProps) {
  
  // Generate chart config from metrics
  const chartConfig = metrics.reduce((config, metric) => {
    config[metric] = {
      label: metric.charAt(0).toUpperCase() + metric.slice(1),
      color: metric === metrics[0] ? "hsl(var(--chart-1))" : "hsl(var(--chart-2))"
    };
    return config;
  }, {} as ChartConfig);

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig}>
          <AreaChart
            accessibilityLayer
            data={data}
            margin={{
              left: 12,
              right: 12,
            }}
          >
            <CartesianGrid vertical={false} />
            <XAxis
              dataKey={Object.keys(data[0])[0]}
              tickLine={false}
              axisLine={false}
              tickMargin={8}
              tickFormatter={(value) => value.slice(0, 3)}
            />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" />}
            />
            {metrics.map((metric, index) => (
              <Area
                key={metric}
                dataKey={metric}
                type="natural"
                fill={`var(--color-${metric})`}
                fillOpacity={0.4}
                stroke={`var(--color-${metric})`}
                stackId="a"
              />
            ))}
          </AreaChart>
        </ChartContainer>
      </CardContent>
      <CardFooter>
        <div className="flex w-full items-start gap-2 text-sm">
          <div className="grid gap-2">
            <div className="flex items-center gap-2 font-medium leading-none">
              Trending up by {trend.value} {trend.period} <TrendingUp className="h-4 w-4" />
            </div>
            <div className="flex items-center gap-2 leading-none text-muted-foreground">
              {footer}
            </div>
          </div>
        </div>
      </CardFooter>
    </Card>
  )
}
