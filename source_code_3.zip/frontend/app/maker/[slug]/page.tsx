"use client";

import React, { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import api from "@/utils/api";
import Loading from "@/components/Loading";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Save, Plus, Link as LinkIcon } from "lucide-react";
import ReactFlow, {
  Node,
  Edge,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
} from "reactflow";
import "reactflow/dist/style.css";
import {
  NotionNode,
  GDriveNode,
  FileUploadNode,
  AgentDocumentsNode,
  AdditionalDetailsNode,
} from "@/components/flow/CustomNodes";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { API_URL, APP_URL } from "@/lib/constants";

const nodeTypes = {
  notion: NotionNode,
  gdrive: GDriveNode,
  fileUpload: FileUploadNode,
  agentDocuments: AgentDocumentsNode,
  additionalDetails: AdditionalDetailsNode,
};

interface Agent {
  id: number;
  bot_id: string;
  name: string;
  description: string;
  nodes: Node[];
  edges: Edge[];
  notion_url: string | null;
  gdrive_url: string | null;
  additional_details: string | null;
  file_urls: string | null;
}

const defaultNodes: Node[] = [
  {
    id: "agentDocuments",
    type: "agentDocuments",
    position: { x: 300, y: 150 },
    data: { 
      label: "Agent Documents",
      title: "",
      description: ""
    },
  },
  {
    id: "additionalDetails",
    type: "additionalDetails",
    position: { x: 600, y: 150 },
    data: { 
      label: "Additional Details",
      value: ""
    },
  },
];

const defaultEdges: Edge[] = [
  {
    id: "agent-details",
    source: "agentDocuments",
    target: "additionalDetails",
  },
];

const MakerPage: React.FC = () => {
  const { slug } = useParams();
  const router = useRouter();
  const [agent, setAgent] = useState<Agent | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [showDeployDialog, setShowDeployDialog] = useState(false);

  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);

  const isNew = slug === "new";

  // Initial fetch of agent data or setup for new agent
  useEffect(() => {
    if (!isNew) {
      fetchAgent();
    } else {
      // Create a new agent with default values
      const newAgent = {
        id: 0,
        bot_id: "",
        name: "",
        description: "",
        nodes: defaultNodes,
        edges: defaultEdges,
        notion_url: null,
        gdrive_url: null,
        additional_details: null,
        file_urls: null,
      };
      
      setAgent(newAgent);
      
      // Initialize flow with default nodes and edges
      const initialNodes = defaultNodes.map(node => ({
        ...node,
        data: {
          ...node.data,
          title: "",
          description: "",
        }
      }));
      
      setNodes(initialNodes);
      setEdges(defaultEdges);
      setLoading(false);
    }
  }, [slug]);

  // Initialize flow when agent data is loaded
  useEffect(() => {
    if (!agent) return;
    
    // Prepare nodes with proper data and event handlers
    let flowNodes: Node[] = [];
    
    // If agent has nodes, use them; otherwise use defaults
    if (agent.nodes && agent.nodes.length > 0) {
      flowNodes = agent.nodes.map(node => {
        // Ensure node has proper position
        const position = node.position || { 
          x: 100 + Math.random() * 200, 
          y: 100 + Math.random() * 200 
        };
        
        // For agentDocuments node, add title and description from agent
        if (node.type === "agentDocuments") {
          return {
            ...node,
            position,
            data: {
              ...node.data,
              title: agent.name || "",
              description: agent.description || "",
            }
          };
        }
        
        // For additionalDetails node, add value from agent
        if (node.type === "additionalDetails") {
          return {
            ...node,
            position,
            data: {
              ...node.data,
              value: agent.additional_details || "",
            }
          };
        }
        
        // For notion node, add value from agent
        if (node.type === "notion") {
          return {
            ...node,
            position,
            data: {
              ...node.data,
              value: agent.notion_url || "",
            }
          };
        }
        
        // For gdrive node, add value from agent
        if (node.type === "gdrive") {
          return {
            ...node,
            position,
            data: {
              ...node.data,
              value: agent.gdrive_url || "",
            }
          };
        }
        
        return {
          ...node,
          position,
        };
      });
    } else {
      // Use default nodes but with agent data
      flowNodes = defaultNodes.map(node => {
        if (node.type === "agentDocuments") {
          return {
            ...node,
            data: {
              ...node.data,
              title: agent.name || "",
              description: agent.description || "",
            }
          };
        }
        
        if (node.type === "additionalDetails") {
          return {
            ...node,
            data: {
              ...node.data,
              value: agent.additional_details || "",
            }
          };
        }
        
        return node;
      });
    }
    
    // Set flow edges from agent or use defaults
    const flowEdges = agent.edges && agent.edges.length > 0 
      ? agent.edges 
      : defaultEdges;
    
    setNodes(flowNodes);
    setEdges(flowEdges);
  }, [agent]);

  const fetchAgent = async () => {
    try {
      const response = await api(`${API_URL}/agent/${slug}`);
      console.log("Fetched agent:", response.data);
      setAgent(response.data);
      setError(null);
    } catch (error) {
      console.error("Failed to fetch agent:", error);
      setError("Failed to load agent");
    } finally {
      setLoading(false);
    }
  };

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges]
  );

  const handleNodeChange = (nodeId: string, value: string) => {
    // Update node data
    setNodes((nds) =>
      nds.map((node) => {
        if (node.id === nodeId) {
          return { ...node, data: { ...node.data, value } };
        }
        return node;
      })
    );

    // Update agent data based on node type
    setAgent((prev) => {
      if (!prev) return null;
      
      const nodeType = nodes.find(n => n.id === nodeId)?.type;
      
      if (nodeType === "notion") {
        return { ...prev, notion_url: value };
      } else if (nodeType === "gdrive") {
        return { ...prev, gdrive_url: value };
      } else if (nodeType === "additionalDetails") {
        return { ...prev, additional_details: value };
      } else if (nodeType === "fileUpload") {
        return { ...prev, file_urls: value }; // Store as JSON string
      }
      
      return prev;
    });
  };

  const handleTitleChange = (value: string) => {
    // Update agent name
    setAgent(prev => prev ? { ...prev, name: value } : null);
    
    // Update agentDocuments node title
    setNodes(nds => 
      nds.map(node => {
        if (node.type === "agentDocuments") {
          return { ...node, data: { ...node.data, title: value } };
        }
        return node;
      })
    );
  };

  const handleDescriptionChange = (value: string) => {
    // Update agent description
    setAgent(prev => prev ? { ...prev, description: value } : null);
    
    // Update agentDocuments node description
    setNodes(nds => 
      nds.map(node => {
        if (node.type === "agentDocuments") {
          return { ...node, data: { ...node.data, description: value } };
        }
        return node;
      })
    );
  };

  const handleSave = async () => {
    if (!agent) return;
    
    setSaving(true);
    try {
      // Prepare agent data for saving
      const updatedAgent = {
        name: agent.name,
        description: agent.description,
        nodes: nodes.map(node => ({
          id: node.id,
          type: node.type,
          position: node.position,
          data: {
            label: node.data.label,
            value: node.data.value || "",
            title: node.data.title,
            description: node.data.description,
          }
        })),
        edges: edges.map(edge => ({
          id: edge.id,
          source: edge.source,
          target: edge.target
        })),
        notion_url: agent.notion_url,
        gdrive_url: agent.gdrive_url,
        additional_details: agent.additional_details,
        file_urls: agent.file_urls,
      };

      console.log("Saving agent with data:", updatedAgent);

      const response = await api(`${API_URL}/agent/${slug}`, {
        method: "PUT",
        body: JSON.stringify(updatedAgent),
      });

      // Update local state with the response data
      setAgent(response.data);
      setError(null);
    } catch (error) {
      console.error("Failed to save agent:", error);
      setError("Failed to save agent");
    } finally {
      setSaving(false);
    }
  };

  const addNode = (type: string) => {
    const timestamp = Date.now();
    const newNode: Node = {
      id: `${type}-${timestamp}`,
      type,
      position: { 
        x: 100 + Math.random() * 200,
        y: 100 + Math.random() * 200
      },
      data: { 
        label: type.charAt(0).toUpperCase() + type.slice(1),
        value: "",
      },
    };
    setNodes((nds) => [...nds, newNode]);
  };

  const handleNodeDelete = useCallback((nodesToDelete: Node[]) => {
    // Don't allow deletion of core nodes
    const coreNodeIds = ["agentDocuments", "additionalDetails"];
    const nonCoreNodesToDelete = nodesToDelete.filter(
      node => !coreNodeIds.includes(node.id)
    );
    
    if (nonCoreNodesToDelete.length === 0) return;
    
    setNodes((nds) => 
      nds.filter((node) => 
        !nonCoreNodesToDelete.some(n => n.id === node.id)
      )
    );
    
    setEdges((eds) => 
      eds.filter((edge) => 
        !nonCoreNodesToDelete.some(n => 
          n.id === edge.source || n.id === edge.target
        )
      )
    );
  }, [setNodes, setEdges]);

  if (loading) return <Loading />;

  return (
    <div className="h-screen flex">
      {/* Side Panel */}
      <div className="w-64 border-r bg-card p-4">
        <h2 className="font-semibold mb-4">Add Nodes</h2>
        <div className="space-y-2">
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={() => addNode("notion")}
          >
            <Plus className="mr-2 h-4 w-4" />
            Notion
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={() => addNode("gdrive")}
          >
            <Plus className="mr-2 h-4 w-4" />
            Google Drive
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={() => addNode("fileUpload")}
          >
            <Plus className="mr-2 h-4 w-4" />
            File Upload
          </Button>
        </div>
        <div className="mt-8 p-4 bg-muted rounded-lg">
          <h3 className="text-sm font-medium mb-2">Tips</h3>
          <ul className="text-xs space-y-2 text-muted-foreground">
            <li>• Drag from node handles (dots) to create connections</li>
            <li>• Delete nodes using Delete key</li>
            <li>• Drag nodes to reposition them</li>
          </ul>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push("/home?tab=agents")}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-2xl font-bold">
              {isNew ? "Create New Agent" : "Edit Agent"}
            </h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button onClick={handleSave} disabled={saving}>
              <Save className="mr-2 h-4 w-4" />
              {saving ? "Saving..." : "Save"}
            </Button>
            <Dialog open={showDeployDialog} onOpenChange={setShowDeployDialog}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <LinkIcon className="mr-2 h-4 w-4" />
                  Deploy
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Deploy Chatbot</DialogTitle>
                  <DialogDescription>
                    Copy this link to access your chatbot:
                  </DialogDescription>
                </DialogHeader>
                <div className="flex items-center space-x-2">
                  <Input
                    readOnly
                    value={`${APP_URL}/chat/${agent?.bot_id}`}
                  />
                  <Button
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `${APP_URL}/chat/${agent?.bot_id}`
                      );
                    }}
                  >
                    Copy
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {error && (
          <Alert variant="destructive" className="m-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="flex-1">
          <ReactFlow
            nodes={nodes.map(node => ({
              ...node,
              data: {
                ...node.data,
                onChange: (value: string) => handleNodeChange(node.id, value),
                onTitleChange: node.type === "agentDocuments" 
                  ? handleTitleChange
                  : undefined,
                onDescriptionChange: node.type === "agentDocuments"
                  ? handleDescriptionChange
                  : undefined,
                agent: agent,
                bot_id: slug,
              }
            }))}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodesDelete={handleNodeDelete}
            nodeTypes={nodeTypes}
            deleteKeyCode="Delete"
            fitView
          >
            <Background />
            <Controls />
          </ReactFlow>
        </div>
      </div>
    </div>
  );
};

export default MakerPage;
