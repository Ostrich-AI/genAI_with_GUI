import React from 'react'

export default function page() {
  return (
    <div>
         <div className="absolute top-0 -z-10 h-full w-full "><div className="absolute bottom-auto left-auto right-0 top-0 h-[500px] w-[500px] -translate-x-[30%] translate-y-[20%] rounded-full bg-[rgba(173,109,244,0.5)] opacity-50 blur-[80px]"></div></div>
         <div className="absolute top-0 -z-20 h-full w-full "><div className="absolute bottom-auto right-auto left-0 top-0 h-[500px] w-[500px] -translate-x-[30%] translate-y-[20%] rounded-full bg-[rgba(173,109,244,0.5)] opacity-50 blur-[80px]"></div></div>
        <div>page</div>
    </div>
    
  )
}
