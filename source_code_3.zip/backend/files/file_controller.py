from fastapi import APIRouter, UploadFile, File, HTTPException, Request
from . import file_service
import os
import logging
from fastapi import Form
from fastapi.responses import JSONResponse

router = APIRouter(prefix="/file", tags=["files"])

@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """
    Upload a file and get its URL
    """
    try:
        if not file:
            raise HTTPException(status_code=400, detail="No file provided")
            
        logging.info(f"Received file upload request for: {file.filename}")
        
        file_url = await file_service.upload_file(file)
        logging.info(f"File uploaded successfully: {file_url}")
        
        return JSONResponse(
            status_code=200,
            content={ 
                "status": "success", 
                "data": { 
                    "url": os.environ["PUBLIC_API_URL"] + file_url 
                } 
            }
        )
    except Exception as e:
        logging.error(f"File upload failed: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

@router.get("/getAll")
def get_all_files():
    """
    Get a list of all uploaded files with their sizes
    """
    files = file_service.get_all_files()
    return {"files": files}

@router.delete("/{filename}")
def delete_file(filename: str):
    """
    Delete a file by its filename
    """
    file_path = os.path.join(file_service.FILES_DIR, filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    
    try:
        os.remove(file_path)
        return {"message": "File deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to delete file: {str(e)}") 