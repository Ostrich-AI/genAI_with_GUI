import os
import uuid
from fastapi import UploadFile
from constants import DB_PATH

FILES_DIR = os.path.join("_data", "files")

def ensure_files_dir():
    os.makedirs(FILES_DIR, exist_ok=True)

async def upload_file(file: UploadFile) -> str:
    ensure_files_dir()
    
    # Generate unique filename
    file_id = str(uuid.uuid4())
    file_extension = os.path.splitext(file.filename)[1]
    filename = f"{file_id}{file_extension}"
    
    # Save file
    file_path = os.path.join(FILES_DIR, filename)
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    
    # Return the URL path
    return f"/files/{filename}"

def get_all_files():
    ensure_files_dir()
    files = []
    for filename in os.listdir(FILES_DIR):
        file_path = os.path.join(FILES_DIR, filename)
        if os.path.isfile(file_path):
            size_bytes = os.path.getsize(file_path)
            # Convert size to human readable format
            size = f"{size_bytes} bytes"
            if size_bytes > 1024:
                size = f"{size_bytes/1024:.2f} KB"
            if size_bytes > 1024 * 1024:
                size = f"{size_bytes/(1024*1024):.2f} MB"
            
            files.append({
                "filename": filename,
                "url": f"/files/{filename}",
                "size": size,
                "size_bytes": size_bytes
            })
    return files 