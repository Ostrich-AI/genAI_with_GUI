from auth.auth_service import get_current_user
from fastapi import APIRouter, Depends, HTTPException
from typing import List, Optional, Literal
from pydantic import BaseModel
from .service import IngestService

router = APIRouter()
service = IngestService()

Department = Literal['IT', 'Operations', 'Finance', 'Legal', 'Sales', 'Engineering', 'HR']
Sensitivity = Literal['public', 'confidential', 'restricted']

class KnowledgeSourceCreate(BaseModel):
    notion_urls: Optional[List[str]] = []
    gdrive_urls: Optional[List[str]] = []
    file_urls: Optional[List[str]] = []
    department: Department = 'IT'
    sensitivity: Sensitivity = 'public'

class KnowledgeSourceUpdate(KnowledgeSourceCreate):
    department: Optional[Department] = None
    sensitivity: Optional[Sensitivity] = None

@router.post("/knowledge-sources")
async def create_knowledge_source(source: KnowledgeSourceCreate, current_user = Depends(get_current_user)):
    source_id = service.create_knowledge_source(
        user_id=current_user["id"],
        notion_urls=source.notion_urls,
        gdrive_urls=source.gdrive_urls,
        file_urls=source.file_urls,
        department=source.department,
        sensitivity=source.sensitivity
    )
    return {"id": source_id, "message": "Knowledge source created successfully"}

@router.get("/knowledge-sources")
async def get_knowledge_sources(current_user = Depends(get_current_user)):
    sources = service.get_knowledge_sources(user_id=current_user["id"])
    return {"data": sources}

@router.put("/knowledge-sources/{source_id}")
async def update_knowledge_source(source_id: int, source: KnowledgeSourceUpdate, current_user = Depends(get_current_user)):
    success = service.update_knowledge_source(
        source_id=source_id,
        notion_urls=source.notion_urls,
        gdrive_urls=source.gdrive_urls,
        file_urls=source.file_urls,
        department=source.department,
        sensitivity=source.sensitivity
    )
    if not success:
        raise HTTPException(status_code=404, detail="Knowledge source not found")
    return {"message": "Knowledge source updated successfully"}

@router.delete("/knowledge-sources/{source_id}")
async def delete_knowledge_source(source_id: int, current_user = Depends(get_current_user)):
    success = service.delete_knowledge_source(source_id)
    if not success:
        raise HTTPException(status_code=404, detail="Knowledge source not found")
    return {"message": "Knowledge source deleted successfully"} 