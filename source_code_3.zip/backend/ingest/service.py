import sqlite3
import json
from typing import List, Optional
from datetime import datetime
from constants import DB_PATH

class IngestService:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.cursor = self.conn.cursor()

    def create_knowledge_source(
        self, 
        user_id: int, 
        notion_urls: List[str] = None, 
        gdrive_urls: List[str] = None, 
        file_urls: List[str] = None,
        department: str = 'IT',
        sensitivity: str = 'public'
    ):
        notion_json = json.dumps(notion_urls or [])
        gdrive_json = json.dumps(gdrive_urls or [])
        file_json = json.dumps(file_urls or [])
        
        self.cursor.execute("""
            INSERT INTO knowledge_sources (
                user_id, notion_urls, gdrive_urls, file_urls, 
                department, sensitivity
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (user_id, notion_json, gdrive_json, file_json, department, sensitivity))
        self.conn.commit()
        return self.cursor.lastrowid

    def get_knowledge_sources(self, user_id: Optional[int] = None):
        if user_id:
            self.cursor.execute("SELECT * FROM knowledge_sources WHERE user_id = ?", (user_id,))
        else:
            self.cursor.execute("SELECT * FROM knowledge_sources")
        
        rows = self.cursor.fetchall()
        sources = []
        for row in rows:
            sources.append({
                "id": row[0],
                "user_id": row[1],
                "notion_urls": json.loads(row[2] or '[]'),
                "gdrive_urls": json.loads(row[3] or '[]'),
                "file_urls": json.loads(row[4] or '[]'),
                "department": row[5],
                "sensitivity": row[6],
                "created_at": row[7],
                "updated_at": row[8]
            })
        return sources

    def update_knowledge_source(
        self, 
        source_id: int, 
        notion_urls: List[str] = None, 
        gdrive_urls: List[str] = None, 
        file_urls: List[str] = None,
        department: str = None,
        sensitivity: str = None
    ):
        current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        updates = []
        params = []
        
        if notion_urls is not None:
            updates.append("notion_urls = ?")
            params.append(json.dumps(notion_urls))
        if gdrive_urls is not None:
            updates.append("gdrive_urls = ?")
            params.append(json.dumps(gdrive_urls))
        if file_urls is not None:
            updates.append("file_urls = ?")
            params.append(json.dumps(file_urls))
        if department is not None:
            updates.append("department = ?")
            params.append(department)
        if sensitivity is not None:
            updates.append("sensitivity = ?")
            params.append(sensitivity)
        
        updates.append("updated_at = ?")
        params.append(current_time)
        params.append(source_id)
        
        query = f"""
            UPDATE knowledge_sources 
            SET {', '.join(updates)}
            WHERE id = ?
        """
        
        self.cursor.execute(query, params)
        self.conn.commit()
        return self.cursor.rowcount > 0

    def delete_knowledge_source(self, source_id: int):
        self.cursor.execute("DELETE FROM knowledge_sources WHERE id = ?", (source_id,))
        self.conn.commit()
        return self.cursor.rowcount > 0

    def __del__(self):
        self.conn.close() 