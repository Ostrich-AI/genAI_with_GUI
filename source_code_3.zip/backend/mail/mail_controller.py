from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from mail.mail_service import send_email


class MailRequest(BaseModel):
    to: EmailStr
    subject: str
    body_text: str = None


router = APIRouter(prefix="/mail", tags=["mail"])


@router.post("/send-mail")
async def send_mail(request: MailRequest):
    try:
        send_email(to_email=request.to, subject=request.subject, body=request.body_text)
        return {"message": "Email sent successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
