import bcrypt
from auth.auth_service import create_jwt_token, decode_jwt_token, get_current_user as get_user_from_token
from users.user_service import get_user
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm

router = APIRouter(prefix="/auth", tags=["Authentication"])

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

@router.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    Get the token for the user.
    JWT Bearer Token is used for authentication.
    """
    user = get_user(form_data.username)
    if not user or not bcrypt.checkpw(
        form_data.password.encode("utf-8"), user[1].encode("utf-8")
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials"
        )
    # user tuple is (username, password, is_admin, role)
    token = create_jwt_token(user[0], user[2], user[3])
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me")
async def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    Get the current user details including employee status.
    """
    user = await get_user_from_token(token)
    return {
        "username": user["username"],
        "is_admin": user["is_admin"],
        "role": user["role"],
        "id": user["id"],
        "employee_status": user["employee_status"]
    }
