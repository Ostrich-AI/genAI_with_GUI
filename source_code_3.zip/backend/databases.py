import sqlite3
import os
import bcrypt
from constants import DB_PATH

# Ensure default users exist
def initialize_db():
    # Create _data directory if it doesn't exist
    os.makedirs("_data", exist_ok=True)
    os.makedirs("_data/files", exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH,check_same_thread=False)
    cursor = conn.cursor()
    
    # Create users table with role and employee_status
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            is_admin INTEGER,
            role TEXT CHECK(role IN ('contractor', 'intern', 'manager', 'admin')) DEFAULT 'intern',
            employee_status TEXT CHECK(employee_status IN ('terminated', 'contract', 'part-time', 'full-time')) DEFAULT 'full-time'
        )
    """)
    
    # Create knowledge_sources table with department and sensitivity
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS knowledge_sources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            notion_urls TEXT,  -- JSON array of Notion URLs
            gdrive_urls TEXT,  -- JSON array of Google Drive URLs
            file_urls TEXT,    -- JSON array of uploaded file URLs
            department TEXT CHECK(department IN ('IT', 'Operations', 'Finance', 'Legal', 'Sales', 'Engineering', 'HR')) DEFAULT 'IT',
            sensitivity TEXT CHECK(sensitivity IN ('public', 'confidential', 'restricted')) DEFAULT 'public',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Add department and sensitivity columns if they don't exist
    try:
        cursor.execute("ALTER TABLE knowledge_sources ADD COLUMN department TEXT CHECK(department IN ('IT', 'Operations', 'Finance', 'Legal', 'Sales', 'Engineering', 'HR')) DEFAULT 'IT'")
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        cursor.execute("ALTER TABLE knowledge_sources ADD COLUMN sensitivity TEXT CHECK(sensitivity IN ('public', 'confidential', 'restricted')) DEFAULT 'public'")
    except sqlite3.OperationalError:
        pass  # Column already exists

    # Add role and employee_status columns if they don't exist
    try:
        cursor.execute("ALTER TABLE users ADD COLUMN role TEXT CHECK(role IN ('contractor', 'intern', 'manager', 'admin')) DEFAULT 'intern'")
    except sqlite3.OperationalError:
        pass  # Column already exists

    try:
        cursor.execute("ALTER TABLE users ADD COLUMN employee_status TEXT CHECK(employee_status IN ('terminated', 'contract', 'part-time', 'full-time')) DEFAULT 'full-time'")
    except sqlite3.OperationalError:
        pass  # Column already exists
    
    # Create agents table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS agents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            bot_id TEXT UNIQUE,
            name TEXT,
            description TEXT,
            nodes TEXT,  -- JSON string for node positions and data
            edges TEXT,  -- JSON string for edge connections
            notion_url TEXT,
            gdrive_url TEXT,
            file_urls TEXT,  -- JSON string for uploaded file URLs
            additional_details TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)
    
    # Add file_urls column if it doesn't exist (for existing databases)
    try:
        cursor.execute("ALTER TABLE agents ADD COLUMN file_urls TEXT")
    except sqlite3.OperationalError:
        pass  # Column already exists

    # Create access_control_logs table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS access_control_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_id INTEGER,
            username TEXT,
            user_role TEXT,
            employee_status TEXT,
            resource_sensitivity TEXT,
            action TEXT,
            access_granted BOOLEAN,
            confidence FLOAT,
            past_violations INTEGER,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()

    default_users = [
        ("admin", "admin", 1, "admin", "full-time"),
        ("sujal", "sujal", 0, "manager", "full-time"),
        ("soham", "soham", 0, "contractor", "contract"),
        ("surabhi", "surabhi", 0, "intern", "part-time"),
        ("sagar", "sagar", 0, "manager", "full-time"),
    ]

    for username, password, is_admin, role, employee_status in default_users:
        hashed_pw = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode(
            "utf-8"
        )
        try:
            cursor.execute(
                "INSERT INTO users (username, password, is_admin, role, employee_status) VALUES (?, ?, ?, ?, ?)",
                (username, hashed_pw, is_admin, role, employee_status),
            )
        except sqlite3.IntegrityError:
            # Update role and employee_status for existing users
            cursor.execute(
                "UPDATE users SET role = ?, employee_status = ? WHERE username = ?",
                (role, employee_status, username)
            )

    conn.commit()
    conn.close()
