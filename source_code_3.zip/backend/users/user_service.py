import sqlite3
import bcrypt
from constants import DB_PATH
from typing import Optional, List, Dict
from fastapi import HTTPException


def get_app_users_db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    return conn, conn.cursor()


# Database function
def get_user(username: str):
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT username, password, is_admin, role FROM users WHERE username = ?",
        (username,),
    )
    user = cursor.fetchone()
    conn.close()
    return user


def get_all_users():
    conn, cursor = get_app_users_db()
    cursor.execute("SELECT username, is_admin, role, employee_status FROM users")
    users = cursor.fetchall()
    conn.close()
    return [
        {
            "username": user[0], 
            "is_admin": user[1], 
            "role": user[2],
            "employee_status": user[3]
        } for user in users
    ]


def update_user(
    username: str, new_password: Optional[str] = None, new_role: Optional[str] = None
) -> bool:
    conn, cursor = get_app_users_db()
    try:
        if new_password and new_role:
            hashed_pw = bcrypt.hashpw(
                new_password.encode("utf-8"), bcrypt.gensalt()
            ).decode("utf-8")
            cursor.execute(
                "UPDATE users SET password = ?, role = ? WHERE username = ?",
                (hashed_pw, new_role, username),
            )
        elif new_password:
            hashed_pw = bcrypt.hashpw(
                new_password.encode("utf-8"), bcrypt.gensalt()
            ).decode("utf-8")
            cursor.execute(
                "UPDATE users SET password = ? WHERE username = ?",
                (hashed_pw, username),
            )
        elif new_role:
            cursor.execute(
                "UPDATE users SET role = ? WHERE username = ?", (new_role, username)
            )

        # Check if any rows were affected
        success = cursor.rowcount > 0
        conn.commit()
        return success
    except Exception as e:
        print(f"Error updating user: {e}")
        return False
    finally:
        conn.close()


def delete_user(username: str):
    conn, cursor = get_app_users_db()
    cursor.execute("DELETE FROM users WHERE username = ?", (username,))
    conn.commit()
    conn.close()


def create_user(
    username: str,
    password: str,
    is_admin: int,
    role: str = "intern",
    employee_status: str = "full-time",
):
    if role not in ["contractor", "intern", "manager", "admin"]:
        raise ValueError(
            "Invalid role. Must be one of: contractor, intern, manager, admin"
        )

    conn, cursor = get_app_users_db()
    hashed_pw = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode(
        "utf-8"
    )
    try:
        cursor.execute(
            "INSERT INTO users (username, password, is_admin, role, employee_status) VALUES (?, ?, ?, ?, ?)",
            (username, hashed_pw, is_admin, role, employee_status),
        )
    except sqlite3.IntegrityError:
        return False
    conn.commit()
    conn.close()
    return True


def get_user_role(username: str) -> Optional[str]:
    conn, cursor = get_app_users_db()
    try:
        cursor.execute("SELECT role FROM users WHERE username = ?", (username,))
        result = cursor.fetchone()
        return result[0] if result else None
    finally:
        conn.close()


def update_user_role(username: str, new_role: str):
    if new_role not in ["contractor", "intern", "manager", "admin"]:
        raise ValueError(
            "Invalid role. Must be one of: contractor, intern, manager, admin"
        )

    conn, cursor = get_app_users_db()
    try:
        cursor.execute(
            "UPDATE users SET role = ? WHERE username = ?", (new_role, username)
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


class UserService:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row

    def create_user(
        self,
        username: str,
        password: str,
        is_admin: bool = False,
        role: str = "intern",
        employee_status: str = "full-time",
    ) -> dict:
        """Create a new user with the given credentials."""
        cursor = self.conn.cursor()
        hashed_pw = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode(
            "utf-8"
        )

        try:
            cursor.execute(
                "INSERT INTO users (username, password, is_admin, role, employee_status) VALUES (?, ?, ?, ?, ?)",
                (username, hashed_pw, int(is_admin), role, employee_status),
            )
            self.conn.commit()
            return self.get_user_by_username(username)
        except sqlite3.IntegrityError:
            raise HTTPException(status_code=400, detail="Username already exists")

    def get_user_by_username(self, username: str) -> Optional[dict]:
        """Get a user by their username."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT id, username, is_admin, role, employee_status FROM users WHERE username = ?",
            (username,),
        )
        user = cursor.fetchone()
        if user:
            return dict(user)
        return None

    def get_user_by_id(self, user_id: int) -> Optional[dict]:
        """Get a user by their ID."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT id, username, is_admin, role, employee_status FROM users WHERE id = ?",
            (user_id,),
        )
        user = cursor.fetchone()
        if user:
            return dict(user)
        return None

    def verify_password(self, username: str, password: str) -> bool:
        """Verify if the provided password matches the user's stored password."""
        user = self.get_user_by_username(username)
        if not user:
            return False
        return bcrypt.checkpw(
            password.encode("utf-8"), user["password"].encode("utf-8")
        )

    def get_all_users(self) -> List[dict]:
        """Get all users."""
        conn = self.conn
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id, username, is_admin, role, employee_status FROM users")
            users = cursor.fetchall()
            return [{
                "id": user[0],
                "username": user[1],
                "is_admin": bool(user[2]),
                "role": user[3],
                "employee_status": user[4]
            } for user in users]
        finally:
            conn.close()

    def update_user(self, user_id: int, **kwargs) -> Optional[dict]:
        """Update user details."""
        cursor = self.conn.cursor()

        # Remove None values and prepare update statement
        updates = {k: v for k, v in kwargs.items() if v is not None}
        if not updates:
            return None

        # Handle password hashing if password is being updated
        if "password" in updates:
            updates["password"] = bcrypt.hashpw(
                updates["password"].encode("utf-8"), bcrypt.gensalt()
            ).decode("utf-8")

        set_clause = ", ".join(f"{k} = ?" for k in updates.keys())
        values = list(updates.values())
        values.append(user_id)

        cursor.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
        self.conn.commit()

        return self.get_user_by_id(user_id)

    def update_user_employee_status(self, username: str, new_status: str) -> bool:
        """Update a user's employee status."""
        if new_status not in ["full-time", "part-time", "contract", "terminated"]:
            raise ValueError("Invalid employee status")

        cursor = self.conn.cursor()
        try:
            cursor.execute(
                "UPDATE users SET employee_status = ? WHERE username = ?",
                (new_status, username),
            )
            self.conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"Error updating employee status: {e}")
            return False
        finally:
            cursor.close()

    def update_user_role(self, username: str, new_role: str) -> bool:
        """Update a user's role."""
        if new_role not in ["contractor", "intern", "manager", "admin"]:
            raise ValueError(
                "Invalid role. Must be one of: contractor, intern, manager, admin"
            )

        cursor = self.conn.cursor()
        try:
            cursor.execute(
                "UPDATE users SET role = ? WHERE username = ?", (new_role, username)
            )
            self.conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            print(f"Error updating role: {e}")
            return False
        finally:
            cursor.close()

    def delete_user(self, user_id: int) -> bool:
        """Delete a user."""
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
        self.conn.commit()
        return cursor.rowcount > 0


# Create a singleton instance
user_service = UserService()
