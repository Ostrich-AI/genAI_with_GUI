from auth.auth_controller import decode_jwt_token, oauth2_scheme
from fastapi import APIRouter, Depends, HTTPException
from users.user_service import get_all_users, update_user, create_user
from typing import List, Optional
from pydantic import BaseModel
from auth.auth_service import get_current_user
from users.user_service import user_service

router = APIRouter(prefix="/users", tags=["User Management"])

class UserUpdate(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    is_admin: Optional[bool] = None
    role: Optional[str] = None
    employee_status: Optional[str] = None

    class Config:
        schema_extra = {
            "example": {
                "username": "johndoe",
                "password": "newpassword",
                "is_admin": False,
                "role": "manager",
                "employee_status": "part-time"
            }
        }

class UserCreate(BaseModel):
    username: str
    password: str
    is_admin: bool = False
    role: str = "intern"
    employee_status: str = "full-time"

    class Config:
        schema_extra = {
            "example": {
                "username": "johndoe",
                "password": "securepassword",
                "is_admin": False,
                "role": "manager",
                "employee_status": "full-time"
            }
        }

class UserResponse(BaseModel):
    id: int
    username: str
    is_admin: bool
    role: str
    employee_status: str

    class Config:
        orm_mode = True

class EmployeeStatusUpdate(BaseModel):
    new_status: str

    class Config:
        schema_extra = {
            "example": {
                "new_status": "full-time"
            }
        }

@router.get("/")
def list_users(token: str = Depends(oauth2_scheme)):
    """
    List all users. Admin only.
    """
    payload = decode_jwt_token(token)
    if not payload.get("is_admin"):
        raise HTTPException(status_code=403, detail="Not authorized")
    return {"users": get_all_users()}

@router.post("/", response_model=UserResponse)
async def create_user(user: UserCreate, current_user: dict = Depends(get_current_user)):
    """Create a new user."""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Only admins can create users")
    
    try:
        return user_service.create_user(
            username=user.username,
            password=user.password,
            is_admin=user.is_admin,
            role=user.role,
            employee_status=user.employee_status
        )
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/", response_model=List[UserResponse])
async def get_users(current_user: dict = Depends(get_current_user)):
    """Get all users."""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Only admins can view all users")
    return user_service.get_all_users()

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(user_id: int, current_user: dict = Depends(get_current_user)):
    """Get a specific user."""
    if not current_user["is_admin"] and current_user["id"] != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to view this user")
    
    user = user_service.get_user_by_id(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    user_update: UserUpdate,
    current_user: dict = Depends(get_current_user)
):
    """Update a user."""
    if not current_user["is_admin"] and current_user["id"] != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to update this user")
    
    updated_user = user_service.update_user(user_id, **user_update.dict(exclude_unset=True))
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    return updated_user

@router.delete("/{user_id}")
async def delete_user(user_id: int, current_user: dict = Depends(get_current_user)):
    """Delete a user."""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Only admins can delete users")
    
    if not user_service.delete_user(user_id):
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted successfully"}

# Admin only routes
@router.get("/list", response_model=List[dict])
async def list_users_admin(current_user: dict = Depends(get_current_user)):
    """List all users (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    return get_all_users()

@router.post("/create")
async def create_user_admin(user_data: UserCreate, current_user: dict = Depends(get_current_user)):
    """Create a new user (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    success = create_user(
        username=user_data.username,
        password=user_data.password,
        is_admin=int(user_data.is_admin),
        role=user_data.role,
        employee_status=user_data.employee_status
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    return {"status": "success", "message": "User created successfully"}

@router.put("/{username}/role")
async def update_user_role(
    username: str, 
    new_role: str, 
    current_user: dict = Depends(get_current_user)
):
    """Update a user's role."""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        success = user_service.update_user_role(username, new_role)
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        return {"status": "success", "message": f"Role updated to {new_role}"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/{username}")
async def update_user_details(
    username: str, 
    user_data: UserUpdate, 
    current_user: dict = Depends(get_current_user)
):
    """Update a user's details (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        update_user(
            username=username,
            password=user_data.password,
            new_role=user_data.role,
            employee_status=user_data.employee_status
        )
        return {"status": "success", "message": "User updated successfully"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/{username}")
async def delete_user_admin(username: str, current_user: dict = Depends(get_current_user)):
    """Delete a user (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    if username == current_user["username"]:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    delete_user(username)
    return {"status": "success", "message": "User deleted successfully"}

@router.get("/roles")
async def get_available_roles(current_user: dict = Depends(get_current_user)):
    """Get list of available roles (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    return {
        "roles": ["contractor", "intern", "manager", "admin"]
    }

@router.get("/{username}/role")
async def get_user_role(
    username: str, 
    current_user: dict = Depends(get_current_user)
):
    """Get a user's role (Admin only)"""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    role = get_user_role(username)
    if not role:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"username": username, "role": role}

@router.put("/{username}/employee_status")
async def update_user_employee_status(
    username: str, 
    new_status: str,
    current_user: dict = Depends(get_current_user)
):
    """Update a user's employee status."""
    if not current_user["is_admin"]:
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        if new_status not in ["full-time", "part-time", "contract", "terminated"]:
            raise HTTPException(status_code=400, detail="Invalid employee status. Must be one of: full-time, part-time, contract, terminated")
            
        success = user_service.update_user_employee_status(username, new_status)
        if not success:
            raise HTTPException(status_code=404, detail="User not found")
        return {"status": "success", "message": f"Employee status updated to {new_status}"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
