from fastapi import APIRouter, Depends, HTTPException
from typing import Dict, List, Optional
from pydantic import BaseModel
from auth.auth_service import get_current_user
from . import agent_service
import json

router = APIRouter(prefix="/agent", tags=["agents"])

class AgentCreate(BaseModel):
    name: str
    description: Optional[str] = None
    nodes: List[Dict]
    edges: List[Dict]
    notion_url: Optional[str] = None
    gdrive_url: Optional[str] = None
    additional_details: Optional[str] = None
    file_urls: Optional[str] = None  # Store as JSON string

class AgentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    nodes: Optional[List[Dict]] = None
    edges: Optional[List[Dict]] = None
    notion_url: Optional[str] = None
    gdrive_url: Optional[str] = None
    additional_details: Optional[str] = None
    file_urls: Optional[str] = None  # Store as JSON string

@router.post("/create")
async def create_agent(agent_data: AgentCreate, current_user: Dict = Depends(get_current_user)):
    """Create a new agent for the current user"""
    try:
        agent = agent_service.create_agent(
            user_id=current_user["id"],
            name=agent_data.name,
            description=agent_data.description,
            nodes=agent_data.nodes,
            edges=agent_data.edges,
            notion_url=agent_data.notion_url,
            gdrive_url=agent_data.gdrive_url,
            additional_details=agent_data.additional_details,
            file_urls=agent_data.file_urls
        )
        return {"status": "success", "data": agent}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/list")
async def list_agents(current_user: Dict = Depends(get_current_user)):
    """Get all agents for the current user"""
    try:
        agents = agent_service.get_user_agents(current_user["id"])
        return {"status": "success", "data": agents}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{bot_id}")
async def get_agent(bot_id: str, current_user: Dict = Depends(get_current_user)):
    """Get a specific agent by bot_id"""
    agent = agent_service.get_agent(current_user["id"], bot_id)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"status": "success", "data": agent}

@router.put("/{bot_id}")
async def update_agent(bot_id: str, agent_data: dict, current_user: Dict = Depends(get_current_user)):
    """Update an existing agent"""
    if not agent_data:
        raise HTTPException(status_code=400, detail="No valid update data provided")
    
    # Extract the relevant fields from the frontend data
    updates = {
        "name": agent_data.get("name"),
        "description": agent_data.get("description"),
        "nodes": agent_data.get("nodes"),
        "edges": agent_data.get("edges"),
        "notion_url": agent_data.get("notion_url"),
        "gdrive_url": agent_data.get("gdrive_url"),
        "additional_details": agent_data.get("additional_details"),
        "file_urls": agent_data.get("file_urls")
    }
    
    # Ensure file_urls is properly formatted as a string
    if isinstance(updates.get("file_urls"), list):
        updates["file_urls"] = json.dumps(updates["file_urls"])
    
    # Filter out None values
    updates = {k: v for k, v in updates.items() if v is not None}
    
    if not updates:
        raise HTTPException(status_code=400, detail="No valid update data provided")
    
    agent = agent_service.update_agent(current_user["id"], bot_id, updates)
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    return {"status": "success", "data": agent}


@router.delete("/{bot_id}")
async def delete_agent(bot_id: str, current_user: Dict = Depends(get_current_user)):
    """Delete an agent"""
    success = agent_service.delete_agent(current_user["id"], bot_id)
    if not success:
        raise HTTPException(status_code=404, detail="Agent not found")
    
    return {"status": "success", "message": "Agent deleted successfully"} 