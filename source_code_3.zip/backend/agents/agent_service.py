import sqlite3
import json
import uuid
from typing import Dict, List, Optional
from constants import DB_PATH


def get_db():
    return sqlite3.connect(DB_PATH,check_same_thread=False)


def create_agent(
    user_id: int,
    name: str,
    description: str,
    nodes: List[Dict],
    edges: List[Dict],
    notion_url: Optional[str] = None,
    gdrive_url: Optional[str] = None,
    file_urls: Optional[str] = None,
    additional_details: Optional[str] = None,
) -> Dict:
    conn = get_db()
    cursor = conn.cursor()

    bot_id = str(uuid.uuid4())

    try:
        # Extract values from nodes
        notion_urls = []
        gdrive_urls = []
        file_url_list = []
        for node in nodes:
            if node.get("type") == "notion" and node.get("data", {}).get("value"):
                notion_urls.append(node["data"]["value"])
            elif node.get("type") == "gdrive" and node.get("data", {}).get("value"):
                gdrive_urls.append(node["data"]["value"])
            elif node.get("type") == "fileUpload" and node.get("data", {}).get("value"):
                try:
                    file_url_list.extend(json.loads(node["data"]["value"]))
                except:
                    pass

        # Store as JSON arrays
        notion_url = json.dumps(notion_urls) if notion_urls else None
        gdrive_url = json.dumps(gdrive_urls) if gdrive_urls else None
        file_urls = json.dumps(file_url_list) if file_url_list else None

        cursor.execute(
            """
            INSERT INTO agents (user_id, bot_id, name, description, nodes, edges, notion_url, gdrive_url, file_urls, additional_details)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                user_id,
                bot_id,
                name,
                description,
                json.dumps(nodes),
                json.dumps(edges),
                notion_url,
                gdrive_url,
                file_urls,
                additional_details,
            ),
        )
        conn.commit()

        # Get the created agent
        cursor.execute("SELECT * FROM agents WHERE bot_id = ?", (bot_id,))
        agent = cursor.fetchone()

    finally:
        conn.close()

    return _format_agent(agent)


def get_user_agents(user_id: int) -> List[Dict]:
    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "SELECT * FROM agents WHERE user_id = ? ORDER BY updated_at DESC",
            (user_id,),
        )
        agents = cursor.fetchall()
    finally:
        conn.close()

    return [_format_agent(agent) for agent in agents]


def get_agent(user_id: int, bot_id: str) -> Optional[Dict]:
    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "SELECT * FROM agents WHERE user_id = ? AND bot_id = ?", (user_id, bot_id)
        )
        agent = cursor.fetchone()
    finally:
        conn.close()

    return _format_agent(agent) if agent else None


def update_agent(user_id: int, bot_id: str, updates: Dict) -> Optional[Dict]:
    conn = get_db()
    cursor = conn.cursor()
    
    # Extract values from nodes if present
    if 'nodes' in updates:
        notion_urls = []
        gdrive_urls = []
        file_url_list = []
        for node in updates['nodes']:
            if node.get('type') == 'notion' and node.get('data', {}).get('value'):
                notion_urls.append(node['data']['value'])
            elif node.get('type') == 'gdrive' and node.get('data', {}).get('value'):
                gdrive_urls.append(node['data']['value'])
            elif node.get('type') == 'fileUpload' and node.get('data', {}).get('value'):
                try:
                    value = node['data']['value']
                    if isinstance(value, str):
                        parsed_value = json.loads(value)
                        if isinstance(parsed_value, list):
                            file_url_list.extend(parsed_value)
                    elif isinstance(value, list):
                        file_url_list.extend(value)
                except:
                    pass
        
        # Ensure all URLs are JSON serialized
        updates['notion_url'] = json.dumps(notion_urls) if notion_urls else None
        updates['gdrive_url'] = json.dumps(gdrive_urls) if gdrive_urls else None
        updates['nodes'] = json.dumps(updates['nodes'])
        updates['edges'] = json.dumps(updates.get('edges', []))

        # Only update file_urls from nodes if not provided directly
        if 'file_urls' not in updates and file_url_list:
            updates['file_urls'] = json.dumps(file_url_list)
    
    # Handle file_urls if provided directly in updates
    if 'file_urls' in updates and updates['file_urls']:
        try:
            # If it's already a JSON string, validate it
            if isinstance(updates['file_urls'], str):
                json.loads(updates['file_urls'])  # Validate JSON
            else:
                # If it's not a string (e.g., a list), serialize it
                updates['file_urls'] = json.dumps(updates['file_urls'])
        except json.JSONDecodeError:
            # If invalid JSON, keep as None
            updates['file_urls'] = None
    
    # Prepare update fields
    valid_fields = ['name', 'description', 'nodes', 'edges', 'notion_url', 'gdrive_url', 'file_urls', 'additional_details']
    update_fields = []
    values = []
    
    for field in valid_fields:
        if field in updates:
            update_fields.append(f"{field} = ?")
            values.append(updates[field])
    
    if not update_fields:
        return None
    
    # Add updated_at
    update_fields.append("updated_at = CURRENT_TIMESTAMP")
    
    try:
        # Update the agent
        query = f"""
            UPDATE agents 
            SET {', '.join(update_fields)}
            WHERE user_id = ? AND bot_id = ?
        """
        values.extend([user_id, bot_id])
        
        cursor.execute(query, values)
        conn.commit()
        
        if cursor.rowcount == 0:
            return None
            
        # Get updated agent
        cursor.execute("SELECT * FROM agents WHERE user_id = ? AND bot_id = ?", (user_id, bot_id))
        agent = cursor.fetchone()
        
    finally:
        conn.close()
    
    return _format_agent(agent) if agent else None


def delete_agent(user_id: int, bot_id: str) -> bool:
    conn = get_db()
    cursor = conn.cursor()

    try:
        cursor.execute(
            "DELETE FROM agents WHERE user_id = ? AND bot_id = ?", (user_id, bot_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    finally:
        conn.close()


def _format_agent(agent_tuple) -> Dict:
    """Convert agent tuple to dictionary with parsed JSON fields"""
    if not agent_tuple:
        return None

    # Parse JSON fields
    try:
        nodes = json.loads(agent_tuple[5]) if agent_tuple[5] else []
        edges = json.loads(agent_tuple[6]) if agent_tuple[6] else []
        notion_url = json.loads(agent_tuple[7]) if agent_tuple[7] else []
        gdrive_url = json.loads(agent_tuple[8]) if agent_tuple[8] else []
        file_urls = json.loads(agent_tuple[9]) if agent_tuple[9] else []
    except json.JSONDecodeError:
        # Handle case where JSON is invalid
        nodes = []
        edges = []
        notion_url = []
        gdrive_url = []
        file_urls = []

    # Create a map of node types to their values
    notion_nodes = [n for n in nodes if n.get("type") == "notion"]
    gdrive_nodes = [n for n in nodes if n.get("type") == "gdrive"]

    # Update node values from stored URLs
    updated_nodes = []
    for node in nodes:
        node_type = node.get("type")

        # Create a copy of the node to avoid modifying the original
        updated_node = {**node}
        updated_node["data"] = {**node.get("data", {})}

        # Set values based on node type
        if node_type == "notion":
            # Find the index of this node in the notion_nodes list
            idx = notion_nodes.index(node) if node in notion_nodes else -1
            if idx >= 0 and idx < len(notion_url):
                updated_node["data"]["value"] = notion_url[idx]

        elif node_type == "gdrive":
            # Find the index of this node in the gdrive_nodes list
            idx = gdrive_nodes.index(node) if node in gdrive_nodes else -1
            if idx >= 0 and idx < len(gdrive_url):
                updated_node["data"]["value"] = gdrive_url[idx]

        elif node_type == "fileUpload":
            updated_node["data"]["value"] = json.dumps(file_urls)

        elif node_type == "additionalDetails":
            updated_node["data"]["value"] = agent_tuple[10] or ""

        elif node_type == "agentDocuments":
            updated_node["data"]["title"] = agent_tuple[3] or ""  # name
            updated_node["data"]["description"] = agent_tuple[4] or ""  # description

        updated_nodes.append(updated_node)

    # If no nodes exist, create default ones
    if not updated_nodes:
        updated_nodes = [
            {
                "id": "agentDocuments",
                "type": "agentDocuments",
                "position": {"x": 300, "y": 150},
                "data": {
                    "label": "Agent Documents",
                    "title": agent_tuple[3] or "",  # name
                    "description": agent_tuple[4] or "",  # description
                },
            },
            {
                "id": "additionalDetails",
                "type": "additionalDetails",
                "position": {"x": 600, "y": 150},
                "data": {
                    "label": "Additional Details",
                    "value": agent_tuple[10] or "",  # additional_details
                },
            },
        ]

        # If no edges exist, create default ones
        if not edges:
            edges = [
                {
                    "id": "agent-details",
                    "source": "agentDocuments",
                    "target": "additionalDetails",
                }
            ]

    # Format dates if needed
    created_at = agent_tuple[11]
    updated_at = agent_tuple[12]
    if created_at and not isinstance(created_at, str):
        created_at = created_at.isoformat()
    if updated_at and not isinstance(updated_at, str):
        updated_at = updated_at.isoformat()

    return {
        "id": agent_tuple[0],
        "user_id": agent_tuple[1],
        "bot_id": agent_tuple[2],
        "name": agent_tuple[3],
        "description": agent_tuple[4],
        "nodes": updated_nodes,
        "edges": edges,
        "notion_url": notion_url,
        "gdrive_url": gdrive_url,
        "file_urls": file_urls,
        "additional_details": agent_tuple[10],
        "created_at": created_at,
        "updated_at": updated_at,
    }
