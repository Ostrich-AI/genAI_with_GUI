import os

from dotenv import load_dotenv

# Load API keys from backend/.env before any module reads them at import time.
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from databases import initialize_db

initialize_db()


from agents import agent_controller
from auth import auth_controller
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.staticfiles import StaticFiles
from files import file_controller
from rag import access_controller
from users import user_controller
from rag import rag_controller
from mail import mail_controller
from ingest import controller as ingest_controller

# from firecrawl import crawl
from crawlfire import crawl


app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allows all methods
    allow_headers=["*"],  # Allows all headers
)

# Ensure the _data/data_images directory exists
data_images_path = "_data/data_images"
os.makedirs(data_images_path, exist_ok=True)
# Mount static files directory
app.mount("/files", StaticFiles(directory="_data/files"), name="files")
app.mount(
    "/data_images", StaticFiles(directory="_data/data_images"), name="data_images"
)

# Include Routers
app.include_router(auth_controller.router)
app.include_router(user_controller.router)
app.include_router(file_controller.router)
app.include_router(agent_controller.router)
app.include_router(access_controller.router)
app.include_router(rag_controller.router)
app.include_router(
    ingest_controller.router, prefix="/knowledge-sources", tags=["knowledge-sources"]
)
app.include_router(crawl.router)
app.include_router(mail_controller.router)


from rag import rag_service


print("Initial ingesting data...")
rag_service.ingest()
