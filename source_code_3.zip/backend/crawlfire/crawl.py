from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from firecrawl import FirecrawlApp # type: ignore
import logging
import os
from fpdf import FPDF

# Initialize the FastAPI app
router = APIRouter()

# Set up logging
logging.basicConfig(level=logging.INFO)

# Set FIRECRAWL_API_KEY in backend/.env
FIRECRAWL_API_KEY = os.getenv("FIRECRAWL_API_KEY", "")

# Define the expected request body
class CrawlRequest(BaseModel):
    url: str

# Define the crawl endpoint
@router.post("/crawl")
async def crawl_endpoint(request: CrawlRequest):
    if not FIRECRAWL_API_KEY:
        raise HTTPException(status_code=500, detail="API key is missing or invalid.")

    try:
        fc_app = FirecrawlApp(api_key=FIRECRAWL_API_KEY)

        # Create a cache filename based on the URL
        safe_filename = request.url.replace("://", "_").replace("/", "_")
        cache_dir = os.path.join("_data", "cache")
        os.makedirs(cache_dir, exist_ok=True)
        cache_file = os.path.join(cache_dir, f"{safe_filename}.cache")
        
        if os.path.exists(cache_file):
            logging.info(f"Loading cached result for URL: {request.url}")
            with open(cache_file, "r", encoding="utf-8") as f:
                cached_html = f.read()
                scrape_result = {"html": cached_html}
        else:
            logging.info(f"Scraping URL: {request.url}")
            scrape_result = fc_app.scrape_url(
            request.url, 
            params={'formats': ['html']}
            )
            with open(cache_file, "w", encoding="utf-8") as f:
                f.write(scrape_result['html'])
        
        
        # Convert markdown to PDF
        pdf_path = await convert_markdown_to_pdf(scrape_result['html'])

        return {"pdf_path": pdf_path}
        # Convert markdown to PDF
        # pdf_path = await convert_markdown_to_pdf(scrape_result['markdown'], request.url)
        # return {"result": scrape_result}
        # return {"pdf_path": pdf_path}

    except Exception as e:
        logging.error(f"Error during scraping: {e}")
        raise HTTPException(status_code=500, detail=f"Scraping failed: {str(e)}")

async def convert_markdown_to_pdf(markdown_content: str) -> str:
    """Simpler approach to handle Unicode in PDFs."""
    try:
        pdf = FPDF()
        pdf.add_page()
        
        # Use a built-in font
        pdf.set_font("Arial", size=12)
        
        # Clean text - remove or replace problematic characters
        clean_content = markdown_content
        # Replace common Unicode characters with ASCII equivalents
        replacements = {
            '\u2013': '-',    # em dash
            '\u2014': '--',   # en dash
            '\u2018': "'",    # left single quote
            '\u2019': "'",    # right single quote
            '\u201c': '"',    # left double quote
            '\u201d': '"',    # right double quote
            '\u2022': '*',    # bullet
            '\u2026': '...',  # ellipsis
            # Add more replacements as needed
        }
        
        for char, replacement in replacements.items():
            clean_content = clean_content.replace(char, replacement)
        
        # Remove any remaining non-Latin1 characters
        clean_content = clean_content.encode('latin-1', 'ignore').decode('latin-1')
        
        # Write content to PDF
        for line in clean_content.split('\n'):
            if line.strip():
                pdf.multi_cell(0, 10, line)
        
        # Output path
        output_dir = os.path.join("_data", "files")
        os.makedirs(output_dir, exist_ok=True)
        
        pdf_path = os.path.join(output_dir, "output.pdf")
        pdf.output(pdf_path)
        
        logging.info(f"PDF saved successfully at: {pdf_path}")
        return pdf_path
    except Exception as e:
        logging.error(f"Error creating PDF: {e}")
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {str(e)}")