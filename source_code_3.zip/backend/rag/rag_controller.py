from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Dict, Any
from auth.auth_service import get_current_user
import sqlite3
from constants import DB_PATH
from rag.rag_service import query, ingest  # Import the functions directly

router = APIRouter(prefix="/rag", tags=["rag"])

class QueryRequest(BaseModel):
    question: str

    class Config:
        schema_extra = {
            "example": {
                "question": "What are the key features of the product?"
            }
        }

class QueryResponse(BaseModel):
    response: str
    confidence: float
    metadata: Dict[Any, Any]

def log_query_attempt(user: dict, question: str, response: str, confidence: float):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO rag_query_logs (
            user_id, username, question, response,
            confidence, timestamp
        ) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    """, (
        user['id'],
        user['username'],
        question,
        response,
        confidence
    ))
    
    conn.commit()
    conn.close()

@router.post("/ingest")
async def ingest_data_endpoint(current_user: dict = Depends(get_current_user)):
    """
    Ingest data from the specified directory into the RAG pipeline.

    Args:
        current_user: Currently authenticated user (from JWT token)

    Returns:
        A success message upon successful ingestion.
    """
    try:
        # Path to your PDF files

        # Call the ingest_data function from the service
        ingest()

        return {"message": "Data ingestion completed successfully."}

    except Exception as e:
        print(f"Error during data ingestion: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error during data ingestion: {str(e)}"
        )

@router.post("/query", response_model=QueryResponse)
async def process_query(
    request: QueryRequest,
):
    """
    Process a RAG query and return the response with confidence score.

    Args:
        request: QueryRequest containing the question
        current_user: Currently authenticated user (from JWT token)

    Returns:
        QueryResponse containing:
        - response: Generated answer to the question
        - confidence: Confidence score of the response
        - metadata: Additional metadata about the response
    """
    try:
        # Call the query function from the service
        response, confidence, source_files = query(request.question)
        print(f"Response: {response}, Confidence: {confidence}, Source Files: {source_files}")
        # Log the query attempt
        # log_query_attempt(
        #     current_user, 
        #     request.question, 
        #     response.response, 
        #     confidence
        # )

        return QueryResponse(
            response=response,
            confidence=confidence,
            metadata={"source_files": source_files}  # Include the source files in metadata
        )

    except Exception as e:
        print(f"Error processing query: {str(e)}")
        raise HTTPException(
            status_code=500, 
            detail=f"Error processing query: {str(e)}"
        )
