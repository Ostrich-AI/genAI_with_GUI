from auth.auth_service import get_current_user
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Literal
from rag.access_service import service
import sqlite3
from constants import DB_PATH


router = APIRouter(prefix="/access", tags=["access"])

# Define valid values for enums
UserRole = Literal["intern", "contractor", "manager", "admin"]
EmployeeStatus = Literal["terminated", "contract", "part-time", "full-time"]
ResourceSensitivity = Literal["public", "confidential", "restricted"]
Action = Literal["read", "download", "edit", "share", "delete"]


class AccessRequest(BaseModel):
    user_role: UserRole
    employee_status: EmployeeStatus
    resource_sensitivity: ResourceSensitivity
    action: Action
    past_violations: int

    class Config:
        schema_extra = {
            "example": {
                "user_role": "manager",
                "employee_status": "full-time",
                "resource_sensitivity": "confidential",
                "action": "edit",
                "past_violations": 0,
            }
        }


class AccessResponse(BaseModel):
    access_granted: bool
    confidence: float
    message: str


def log_access_attempt(user: dict, request: AccessRequest, access_granted: bool, confidence: float):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT INTO access_control_logs (
            user_id, username, user_role, employee_status,
            resource_sensitivity, action, access_granted,
            confidence, past_violations
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        user['id'],
        user['username'],
        request.user_role,
        request.employee_status,
        request.resource_sensitivity,
        request.action,
        access_granted,
        confidence,
        request.past_violations
    ))
    
    conn.commit()
    conn.close()


@router.post("/predict", response_model=AccessResponse)
async def predict_access(
    request: AccessRequest, current_user: dict = Depends(get_current_user)
):
    """
    Predict whether access should be granted based on user and resource attributes.

    Args:
        request: AccessRequest containing user and resource details
        current_user: Currently authenticated user (from JWT token)

    Returns:
        AccessResponse containing:
        - access_granted: Boolean indicating if access is granted
        - confidence: Confidence score of the prediction
        - message: Human-readable explanation of the decision
    """
    try:
        # Get prediction from service
        prediction, confidence = service.predict_access(
            user_role=request.user_role,
            employee_status=request.employee_status,
            resource_sensitivity=request.resource_sensitivity,
            action=request.action,
            past_violations=request.past_violations,
        )

        # Create response
        access_granted = bool(prediction)
        message = "Access granted" if access_granted else "Access denied"

        # Log the access attempt
        log_access_attempt(current_user, request, access_granted, confidence)

        return AccessResponse(
            access_granted=access_granted,
            confidence=confidence,
            message=message
        )

    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error processing access request: {str(e)}"
        )



@router.get("/logs", response_model=list)
async def get_latest_logs(current_user: dict = Depends(get_current_user)):
    """
    Retrieve the latest 50 access control logs.

    Args:
        current_user: Currently authenticated user (from JWT token)

    Returns:
        List of the latest 50 access control logs.
    """
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT user_id, username, user_role, employee_status,
                    resource_sensitivity, action, access_granted,
                    confidence, past_violations, timestamp
            FROM access_control_logs
            ORDER BY timestamp DESC
            LIMIT 50
        """)
        logs = cursor.fetchall()
        conn.close()

        return [
            {
                "user_id": log[0],
                "username": log[1],
                "user_role": log[2],
                "employee_status": log[3],
                "resource_sensitivity": log[4],
                "action": log[5],
                "access_granted": bool(log[6]),
                "confidence": log[7],
                "past_violations": log[8],
                "timestamp": log[9],
            }
            for log in logs
        ]

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error retrieving logs: {str(e)}"
        )