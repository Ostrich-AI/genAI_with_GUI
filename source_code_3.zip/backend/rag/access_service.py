import os
import joblib
import pandas as pd
from typing import Tuple
from fastapi import HTTPException

class AccessService:
    def __init__(self):
        # Load the model when the service is initialized
        model_path = os.path.join(os.path.dirname(__file__), "xgb_model.joblib")
        try:
            self.model = joblib.load(model_path)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to load ML model: {str(e)}")

        # Define mapping dictionaries
        self.role_map = {"intern": 0, "contractor": 1, "manager": 2, "admin": 3}
        self.status_map = {"terminated": 0, "contract": 1, "part-time": 2, "full-time": 3}
        self.sensitivity_map = {"public": 0, "confidential": 1, "restricted": 2}
        self.action_map = {"read": 0, "download": 1, "edit": 2, "share": 3, "delete": 4}

    def predict_access(
        self,
        user_role: str,
        employee_status: str,
        resource_sensitivity: str,
        action: str,
        past_violations: int
    ) -> Tuple[int, float]:
        """
        Predict whether access should be granted and return confidence score.
        
        Args:
            user_role: Role of the user (intern, contractor, manager, admin)
            employee_status: Status of the employee (terminated, contract, part-time, full-time)
            resource_sensitivity: Sensitivity level of the resource (public, confidential, restricted)
            action: Action being attempted (read, download, edit, share, delete)
            past_violations: Number of past violations by the user
            
        Returns:
            Tuple containing:
            - prediction (0 for denied, 1 for granted)
            - confidence score (float between 0 and 1)
        """
        try:
            # Validate inputs
            if user_role not in self.role_map:
                raise HTTPException(status_code=400, detail=f"Invalid user role: {user_role}")
            if employee_status not in self.status_map:
                raise HTTPException(status_code=400, detail=f"Invalid employee status: {employee_status}")
            if resource_sensitivity not in self.sensitivity_map:
                raise HTTPException(status_code=400, detail=f"Invalid resource sensitivity: {resource_sensitivity}")
            if action not in self.action_map:
                raise HTTPException(status_code=400, detail=f"Invalid action: {action}")
            if not isinstance(past_violations, int) or past_violations < 0:
                raise HTTPException(status_code=400, detail="Past violations must be a non-negative integer")

            # Create DataFrame from input
            input_data = pd.DataFrame([{
                "user_role": self.role_map[user_role],
                "employee_status": self.status_map[employee_status],
                "resource_sensitivity": self.sensitivity_map[resource_sensitivity],
                "action": self.action_map[action],
                "past_violations": past_violations
            }])

            # Make prediction
            prediction = self.model.predict(input_data)
            probability = self.model.predict_proba(input_data)
            confidence = max(probability[0])

            return int(prediction[0]), float(confidence)

        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error making prediction: {str(e)}")

# Create and export the service instance
service = AccessService() 