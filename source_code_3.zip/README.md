# Kiwi AI: Retrieval-Augmented Generation

[![Maintenance](https://img.shields.io/badge/Maintained%3F-yes-green.svg)](https://github.com/YOUR_GITHUB_USERNAME/YOUR_REPO_NAME)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Made with FastAPI](https://img.shields.io/badge/Made%20with-FastAPI-0055FF?style=flat-square&logo=python&labelColor=grey)](https://fastapi.tiangolo.com/)
[![Built with Next.js](https://img.shields.io/badge/Built%20with-Next.js-black?style=flat-square&logo=next.js&labelColor=grey)](https://nextjs.org/)

This project presents an advanced Generative UI Chatbot, designed to facilitate streamlined and secure data interaction within enterprise environments. The system leverages Retrieval-Augmented Generation (RAG) in conjunction with dynamically rendered UI elements to provide contextually relevant and actionable information.

## Executive Summary

The Generative UI Chatbot addresses the challenge of data silos and inefficient information access by providing a unified platform for querying and interacting with diverse datasets. Unlike traditional chatbots, this system employs a sophisticated RAG pipeline to retrieve relevant information, which is then presented through dynamically generated UI components, enhancing user engagement and operational efficiency. Security and access control are paramount, ensuring compliance and data protection.

## Key Features and Technical Specifications

*   **Intelligent Data Integration and Orchestration:**
    *   **Multimodal Data Ingestion:** The system supports the ingestion and indexing of data from disparate sources, including text documents, images, PDFs, and multimedia assets.
    *   **Third-Party API Integration:** Seamless integration with industry-standard platforms such as Notion, Dropbox, and Google Drive enables efficient data acquisition and processing. Data flow is visually orchestrated using a Reactflow-based architecture with a FastAPI backend, facilitating custom node definition and streamlined data pipelines.

*   **Granular Role-Based Access Control (RBAC):**
    *   **Administrative Privileges:** Dedicated administrative roles provide control over the knowledge base, allowing for the management of datasets with varying levels of sensitivity (Restricted, Confidential, Public).
    *   **Permission Management:** Non-administrative users are granted access based on their defined roles, ensuring data segregation and compliance with internal security policies.

*   **AI-Driven Permission Validation:**
    *   **XGBoost Classification Model:** Prior to data retrieval, an XGBoost-based classification model evaluates user requests, determining authorization based on factors such as user role, resource sensitivity, and historical violations.
    *   **Performance Metrics:** XGBoost outperforms alternative models, achieving a classification accuracy of 99% during internal evaluations (Logistic Regression: 80%, Decision Tree: 95%).

*   **Robust Multimodal RAG Pipeline with LLM-Based Guardrails:**
    *   **LLM-GUARD Integration:** The RAG pipeline incorporates LLM-GUARD to provide robust input and output validation, ensuring secure and reliable responses.
    *   **Multimodal Data Processing:** The system supports multimodal data types, including text, tables, images, and diagrams, enabling comprehensive information retrieval.
    *   **Cost-Effective Inference:** The pipeline utilizes the Gemini 2 Flash model via a free API for inference, minimizing operational costs during development and testing phases. The system architecture is designed to accommodate alternative guardrail frameworks as required.

    ```
    Multimodal RAG Pipeline with Guardrails Provided by LLM-GUARD

    This architecture features a Multimodal Retrieval-Augmented Generation (RAG) pipeline fortified with integrated guardrails from LLM-GUARD, ensuring secure, dependable, and contextually precise responses. The pipeline is engineered to process diverse multimodal inputs (e.g., text, tables, images, diagrams) while enforcing stringent guardrails to continuously monitor and validate both input and output data streams.

    Note:
    Inference is performed using the Gemini 2 Flash model accessible through a complimentary API, thereby promoting accessibility and minimizing costs during development and experimentation.

    Extension:
    The modular design allows for seamless integration with alternative guardrail frameworks.
    ```

*   **Generative UI Chatbot with Dynamic Component Rendering:**
    *   **Streaming UI Generation:** The chatbot facilitates the rendering of dynamic UI components directly within the chat interface.
    *   **AI-Powered Action Suggestions:** Contextually relevant action suggestions, such as email drafting, report generation, and task scheduling, streamline user workflows.

*   **Centralized Administration and Knowledge Base Management:**
    *   **Admin Dashboard:** A dedicated administrative dashboard provides comprehensive access to uploaded files and facilitates the management of the knowledge base.

## Technical Specifications

*   **Knowledge Indexing & Management:** LlamaIndex
*   **Frontend Development:** Next.js (Typescript)
*   **Backend Development:** FastAPI (Python)
*   **Document Parsing:** LlamaParse, FireCrawl

## Quick Start

### Prerequisites

- **Python 3.10–3.12** (3.11 recommended; 3.13+ cannot install pinned torch/numpy wheels)
- **Node.js 18.18+** (20 LTS recommended)
- **Gemini API key** (required) — [Google AI Studio](https://aistudio.google.com/app/apikey)
- **Groq API key** (optional, for reasoning/voice) — [Groq Console](https://console.groq.com/keys)

### Run the project

**Windows (PowerShell):**

```powershell
.\run.ps1 keys    # set API keys (first time only)
.\run.ps1         # install deps if needed, then start backend + frontend
```

If execution policy blocks the script:

```powershell
powershell -ExecutionPolicy Bypass -File .\run.ps1
```

**Linux / macOS / Git Bash:**

```bash
chmod +x run.sh   # first time only
./run.sh keys     # set API keys (first time only)
./run.sh          # install deps if needed, then start backend + frontend
```

### URLs and login

| Service   | URL                          |
|-----------|------------------------------|
| App       | http://localhost:3000        |
| API docs  | http://localhost:8000/docs   |

Default login: **admin / admin** (other seeded users: sujal, soham, surabhi, sagar — password matches username).

The first backend start downloads embedding/guard models and ingests data; this can take several minutes.

### Other commands

| Command              | Description                                      |
|----------------------|--------------------------------------------------|
| `run setup`          | Install dependencies only                        |
| `run check`          | Show toolchain versions and project state        |
| `run backend`        | Run FastAPI only (port 8000)                     |
| `run frontend`       | Run Next.js only (port 3000)                     |
| `run stop`           | Stop processes on ports 8000 and 3000            |
| `run clean`          | Remove venv, node_modules, .next, and logs       |

Logs are written to the `logs/` directory when both services are started together.

## Contributing

Contributions to this project are welcomed. Please submit issue reports, feature requests, and pull requests following established software development best practices.

## License

This project is licensed under the MIT License. Refer to the [LICENSE](LICENSE) file for complete terms and conditions.